# Fertility Ensemble VSCode Bundle (v2)

Tento balíček je připravený tak, aby šel otevřít jako projekt ve VSCode a spustit "jedním přepínačem"
s logováním přes pipe (`tee` / `Tee-Object`) přímo uvnitř Python skriptu.

## Struktura
- `data/` – vstupní data (annual, panel, kvartály ČSÚ)
- `models/` – 3 modely (v3.8, v4.4, structural age model)
- `demo_outputs/` – předpočítané outputy pro v3.8 (rychlá DEMO)
- `scripts/` – pipeline skripty
  - `one_switch_pipeline.py` – spouštěč (DEMO/FULL)
  - `make_structural_backtest.py` – rolling backtest pro strukturální model (rychlý surrogate)
  - `build_nowcast_ensemble.py` – nowcast (Q1–Q3), kalibrace, váhy, fan-charty

## Kde a jak spustit
**Vždy spouštěj z rootu projektu (tj. z adresáře, kde je `requirements.txt`).**

### 1) Setup
```bash
pip install -r requirements.txt
```

### 2) DEMO (doporučeno pro prezentaci)
DEMO dělá:
- structural backtest (surrogate, rychlé)
- ensemble builder (nowcast + kalibrace + váhy + fan-charty)

DEMO očekává:
- v3.8 forecast/backtest je v `demo_outputs/outputs_v3_8/`
- v4 forecast/backtest musí existovat v `runs/v4/...` (nejdřív jednou spusť FULL)
- structural forecast draws musí existovat v `runs/struct/forecast_draws_long.csv.gz`

Linux/macOS/WSL:
```bash
python scripts/one_switch_pipeline.py --mode demo --shell bash --log logs/demo.log
```

Windows PowerShell:
```powershell
python scripts\one_switch_pipeline.py --mode demo --shell powershell --log logs\demo.log
```

Výstupy: `runs/ensemble_out/`

### 3) FULL (na lokálu – může trvat)
FULL spustí i samplery:
```bash
python scripts/one_switch_pipeline.py --mode full --shell bash --log logs/full.log
```

## Poznámky k výkonu
Pro prezentaci je nejlepší udělat "heavy" výpočty (full samplery) předem a během prezentace spustit jen DEMO část
(nowcast+kalibrace+váhy+grafy). To běží rychle.

## Co poslat zpět (pro finální doladění vah)
Po full běhu pošli:
- `runs/v4/...` forecast_draws + backtest_cases/draws
- `runs/v3_8/...` forecast_draws + backtest_cases/draws
- `runs/struct/...` forecast_draws + `runs/struct_backtest/...` cases/draws
