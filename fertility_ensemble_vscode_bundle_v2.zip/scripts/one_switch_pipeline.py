import argparse
import os
import platform
import shlex
import subprocess
from pathlib import Path


def run_with_shell_pipe(cmd: str, log_path: str, shell: str = "auto") -> None:
    """
    Run command and pipe stdout+stderr to a log file, using a shell pipeline.
    - bash:       ... 2>&1 | tee log.txt
    - powershell: ... 2>&1 | Tee-Object -FilePath log.txt
    """
    log_path = str(Path(log_path))
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)

    system = platform.system().lower()
    if shell == "auto":
        shell = "powershell" if "windows" in system else "bash"

    if shell == "bash":
        piped = f"{cmd} 2>&1 | tee {shlex.quote(log_path)}"
        full = ["bash", "-lc", piped]
        print("[RUN bash]", piped)
        subprocess.run(full, check=True)
    elif shell == "powershell":
        ps_cmd = f'{cmd} 2>&1 | Tee-Object -FilePath "{log_path}"'
        full = ["powershell", "-NoProfile", "-Command", ps_cmd]
        print("[RUN pwsh]", ps_cmd)
        subprocess.run(full, check=True)
    else:
        raise ValueError("shell must be auto|bash|powershell")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["demo", "full"], default="demo")
    ap.add_argument("--shell", default="auto")
    ap.add_argument("--log", default="logs/pipeline.log")

    # Project-root relative paths (default match bundle structure)
    ap.add_argument("--annual_csv", default="data/fertility_annual_v3.csv")
    ap.add_argument("--panel_csv", default="data/fertility_panel_v3.csv")
    ap.add_argument("--quarters_xlsx", default="data/zive_narozene_ctvrtletni.xlsx")

    # Full run scripts
    ap.add_argument("--v38_script", default="models/v3_8/fertility_model_v3_8_pit_beta_anchor_rolling.py")
    ap.add_argument("--v4_script", default="models/v4_4/scripts/fertility_models_v4_4_core_vs_ua_grid.py")
    ap.add_argument("--struct_script", default="models/structural_v1/fertility_structural_v1/scripts/structural_fertility_age_model.py")

    # Structural exposure files (adjust if your extracted folder differs)
    ap.add_argument("--exp_forward", default="models/structural_v1/fertility_structural_v1/data/cz_exposure_forward_2024_2028.csv")
    ap.add_argument("--exp_projection", default="models/structural_v1/fertility_structural_v1/data/cz_exposure_projection_age_year_2025_2081.csv")

    # Outputs
    ap.add_argument("--v38_outdir", default="runs/v3_8")
    ap.add_argument("--v4_outdir", default="runs/v4")
    ap.add_argument("--struct_outdir", default="runs/struct")
    ap.add_argument("--struct_bt_outdir", default="runs/struct_backtest")
    ap.add_argument("--ensemble_outdir", default="runs/ensemble_out")

    # Ensemble settings
    ap.add_argument("--sd_log", type=float, default=0.04)
    ap.add_argument("--tau", type=float, default=0.8333)
    ap.add_argument("--target_cov", type=float, default=0.80)
    ap.add_argument("--grid_step", type=float, default=0.05)
    ap.add_argument("--floor_struct", type=float, default=0.10)
    ap.add_argument("--forecast_start", type=int, default=2025)

    args = ap.parse_args()

    Path("runs").mkdir(exist_ok=True)
    Path("logs").mkdir(exist_ok=True)

    if args.mode == "demo":
        # In demo mode: use bundled v3.8 outputs as-is and only run:
        # - structural surrogate backtest
        # - ensemble builder
        # Note: you can also drop in your own v4/v38 forecast files and it will pick them up.
        cmd_bt = (
            f'python scripts/make_structural_backtest.py '
            f'--mode surrogate --panel "{args.panel_csv}" '
            f'--outdir "{args.struct_bt_outdir}" '
            f'--H 5 --origin_min 2012 --origin_max 2018 --n_draws 600'
        )
        run_with_shell_pipe(cmd_bt, args.log, shell=args.shell)

        # Use demo outputs for v3.8 + (optional) v4 outputs if present; else fallback to best quantiles not used for draws
        # Here we expect that user has already generated v4 forecast+backtest (or will in full mode).
        v38_fore = "demo_outputs/outputs_v3_8/forecast_draws_long_pitcal.csv.gz"
        v38_cases = "demo_outputs/outputs_v3_8/backtest_cases_calibrated.csv"
        v38_draws = "demo_outputs/outputs_v3_8/backtest_draws_long_calibrated.csv.gz"

        # For demo, we require user to provide v4 outputs; if missing, print hint.
        v4_fore = os.path.join(args.v4_outdir, "forecast_5y", "forecast_draws_long.csv.gz")
        v4_cases = os.path.join(args.v4_outdir, "backtest_rolling", "backtest_cases.csv")
        v4_draws = os.path.join(args.v4_outdir, "backtest_rolling", "backtest_draws_long.csv.gz")

        if not (os.path.exists(v4_fore) and os.path.exists(v4_cases) and os.path.exists(v4_draws)):
            print("[DEMO] Missing v4 outputs. Run full mode once, or generate v4 outputs into runs/v4.")
            print("Expected:")
            print(" ", v4_fore)
            print(" ", v4_cases)
            print(" ", v4_draws)
            raise SystemExit(2)

        # Structural forecast draws must exist (generated by your structural script with draw export patch)
        struct_fore = os.path.join(args.struct_outdir, "forecast_draws_long.csv.gz")
        if not os.path.exists(struct_fore):
            print("[DEMO] Missing structural forecast draws:", struct_fore)
            print("Run full mode once OR run your structural script and ensure it writes forecast_draws_long.csv.gz")
            raise SystemExit(2)

        struct_cases = os.path.join(args.struct_bt_outdir, "backtest_cases.csv")
        struct_draws = os.path.join(args.struct_bt_outdir, "backtest_draws_long.csv.gz")

        cmd_ens = (
            f'python scripts/build_nowcast_ensemble.py '
            f'--annual_csv "{args.annual_csv}" '
            f'--quarters_xlsx "{args.quarters_xlsx}" '
            f'--sd_log {args.sd_log} --tau {args.tau} --target_cov {args.target_cov} '
            f'--grid_step {args.grid_step} --floor_struct {args.floor_struct} '
            f'--forecast_start {args.forecast_start} '
            f'--outdir "{args.ensemble_outdir}" '
            f'--v4_forecast "{v4_fore}" --v4_cases "{v4_cases}" --v4_draws "{v4_draws}" '
            f'--v38_forecast "{v38_fore}" --v38_cases "{v38_cases}" --v38_draws "{v38_draws}" '
            f'--struct_forecast "{struct_fore}" --struct_cases "{struct_cases}" --struct_draws "{struct_draws}" '
        )
        run_with_shell_pipe(cmd_ens, args.log, shell=args.shell)

        print("[OK] DEMO finished. See:", args.ensemble_outdir)
        return

    # FULL mode: run all models (may take minutes depending on sampler settings)
    Path(args.v38_outdir).mkdir(parents=True, exist_ok=True)
    Path(args.v4_outdir).mkdir(parents=True, exist_ok=True)
    Path(args.struct_outdir).mkdir(parents=True, exist_ok=True)
    Path(args.struct_bt_outdir).mkdir(parents=True, exist_ok=True)
    Path(args.ensemble_outdir).mkdir(parents=True, exist_ok=True)

    cmd_v38 = (
        f'python "{args.v38_script}" '
        f'--annual "{args.annual_csv}" '
        f'--outdir "{args.v38_outdir}" '
        f'--H 5 --target_cov {args.target_cov}'
    )
    run_with_shell_pipe(cmd_v38, args.log, shell=args.shell)

    cmd_v4 = (
        f'python "{args.v4_script}" '
        f'--annual "{args.annual_csv}" '
        f'--panel "{args.panel_csv}" '
        f'--outdir "{args.v4_outdir}" '
        f'--hmax 5'
    )
    run_with_shell_pipe(cmd_v4, args.log, shell=args.shell)

    cmd_struct = (
        f'python "{args.struct_script}" '
        f'--panel "{args.panel_csv}" '
        f'--exp_forward "{args.exp_forward}" '
        f'--exp_projection "{args.exp_projection}" '
        f'--outdir "{args.struct_outdir}" '
        f'--forecast_start {args.forecast_start} --forecast_horizon 5'
    )
    run_with_shell_pipe(cmd_struct, args.log, shell=args.shell)

    cmd_bt = (
        f'python scripts/make_structural_backtest.py '
        f'--mode surrogate --panel "{args.panel_csv}" '
        f'--outdir "{args.struct_bt_outdir}" '
        f'--H 5 --origin_min 2012 --origin_max 2018 --n_draws 800'
    )
    run_with_shell_pipe(cmd_bt, args.log, shell=args.shell)

    v4_fore = os.path.join(args.v4_outdir, "forecast_5y", "forecast_draws_long.csv.gz")
    v4_cases = os.path.join(args.v4_outdir, "backtest_rolling", "backtest_cases.csv")
    v4_draws = os.path.join(args.v4_outdir, "backtest_rolling", "backtest_draws_long.csv.gz")

    v38_fore = os.path.join(args.v38_outdir, "forecast_draws_long_pitcal.csv.gz")
    v38_cases = os.path.join(args.v38_outdir, "backtest_cases_calibrated.csv")
    v38_draws = os.path.join(args.v38_outdir, "backtest_draws_long_calibrated.csv.gz")

    struct_fore = os.path.join(args.struct_outdir, "forecast_draws_long.csv.gz")
    struct_cases = os.path.join(args.struct_bt_outdir, "backtest_cases.csv")
    struct_draws = os.path.join(args.struct_bt_outdir, "backtest_draws_long.csv.gz")

    cmd_ens = (
        f'python scripts/build_nowcast_ensemble.py '
        f'--annual_csv "{args.annual_csv}" '
        f'--quarters_xlsx "{args.quarters_xlsx}" '
        f'--sd_log {args.sd_log} --tau {args.tau} --target_cov {args.target_cov} '
        f'--grid_step {args.grid_step} --floor_struct {args.floor_struct} '
        f'--forecast_start {args.forecast_start} '
        f'--outdir "{args.ensemble_outdir}" '
        f'--v4_forecast "{v4_fore}" --v4_cases "{v4_cases}" --v4_draws "{v4_draws}" '
        f'--v38_forecast "{v38_fore}" --v38_cases "{v38_cases}" --v38_draws "{v38_draws}" '
        f'--struct_forecast "{struct_fore}" --struct_cases "{struct_cases}" --struct_draws "{struct_draws}" '
    )
    run_with_shell_pipe(cmd_ens, args.log, shell=args.shell)

    print("[OK] FULL finished. See:", args.ensemble_outdir)


if __name__ == "__main__":
    main()
