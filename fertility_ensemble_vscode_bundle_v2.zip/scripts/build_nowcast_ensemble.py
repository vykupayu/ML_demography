import argparse
import json
import math
import os
import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def _ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)


def _read_any(path: str) -> pd.DataFrame:
    if path.endswith(".gz"):
        return pd.read_csv(path, compression="gzip")
    return pd.read_csv(path)


def _find_col(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    cols = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand.lower() in cols:
            return cols[cand.lower()]
    for cand in candidates:
        for c in df.columns:
            if cand.lower() in c.lower():
                return c
    return None


@dataclass
class NowcastResult:
    mu_log_B: float
    sd_log_B: float
    q1q3_2025: float
    r_hist_mean: float
    r_hist_sd: float
    log_r_post_mean: float
    log_r_pred_sd: float
    sanity_h1_2025: Optional[float]


def load_quarterly_births_xlsx(xlsx_path: str) -> pd.DataFrame:
    """
    Reads ČSÚ quarterly export. Expects sheet 'DATA' and header row around 6th row.
    Parses strings like '2025 Q3 [4]'.
    """
    df = pd.read_excel(xlsx_path, sheet_name="DATA", header=5)
    q_col = _find_col(df, ["Čtvrtletí", "ctvrtleti", "quarter"])
    b_col = _find_col(df, ["Živě\nnarození", "živě narození", "births"])
    if q_col is None or b_col is None:
        raise ValueError("Cannot find quarterly columns in xlsx. Please check the 'DATA' sheet.")
    tmp = df[[q_col, b_col]].copy()
    tmp = tmp[tmp[b_col].notna() & tmp[q_col].notna()].copy()

    pat = re.compile(r"(\d{4})\s*Q([1-4])")
    years, qs = [], []
    for s in tmp[q_col].astype(str).tolist():
        m = pat.search(s)
        years.append(int(m.group(1))) if m else years.append(np.nan)
        qs.append(int(m.group(2))) if m else qs.append(np.nan)

    tmp["year"] = years
    tmp["q"] = qs
    tmp = tmp.dropna(subset=["year", "q"])
    tmp["year"] = tmp["year"].astype(int)
    tmp["q"] = tmp["q"].astype(int)
    tmp = tmp.rename(columns={b_col: "births_q"})
    tmp["births_q"] = tmp["births_q"].astype(float)
    tmp = tmp[(tmp["births_q"] > 0) & (tmp["births_q"] < 200000)]
    return tmp[["year", "q", "births_q"]].sort_values(["year", "q"])


def compute_nowcast_from_quarters(
    qdf: pd.DataFrame,
    year_now: int,
    sd_log: float,
    prior_mu_log_r: float = math.log(4 / 3),
    prior_sd_log_r: float = 0.05,
    hist_years_min: int = 2010,
    hist_years_max: int = 2024,
) -> NowcastResult:
    wide = qdf.pivot_table(index="year", columns="q", values="births_q", aggfunc="sum")
    hist = wide.loc[(wide.index >= hist_years_min) & (wide.index <= hist_years_max)].copy()
    for qq in [1, 2, 3, 4]:
        if qq not in hist.columns:
            raise ValueError(f"Missing quarter Q{qq} in quarterly dataset for history years.")
    annual = hist[[1, 2, 3, 4]].sum(axis=1)
    q1q3 = hist[[1, 2, 3]].sum(axis=1)
    r = (annual / q1q3).astype(float)
    log_r = np.log(r.values)

    r_hist_mean = float(np.mean(r.values))
    r_hist_sd = float(np.std(r.values, ddof=1))

    n = len(log_r)
    if n < 5:
        raise ValueError("Too few historical years to estimate annualization ratio r.")

    m = float(np.mean(log_r))
    s2 = float(np.var(log_r, ddof=1))
    se2 = s2 / n

    prior_var = prior_sd_log_r ** 2
    post_var_mean = 1.0 / (1.0 / prior_var + 1.0 / se2)
    post_mean = post_var_mean * (prior_mu_log_r / prior_var + m / se2)

    pred_var = s2 + post_var_mean
    pred_sd = float(np.sqrt(pred_var))

    q_now = qdf[(qdf["year"] == year_now) & (qdf["q"].isin([1, 2, 3]))]["births_q"].sum()
    if not np.isfinite(q_now) or q_now <= 0:
        raise ValueError(f"Cannot compute Q1–Q3 births for year {year_now} from xlsx.")

    h1 = qdf[(qdf["year"] == year_now) & (qdf["q"].isin([1, 2]))]["births_q"].sum()
    sanity_h1 = float(h1) if np.isfinite(h1) and h1 > 0 else None

    mu_log_B = float(np.log(q_now) + post_mean)
    sd_log_B = float(np.sqrt(sd_log**2 + pred_var))

    return NowcastResult(
        mu_log_B=mu_log_B,
        sd_log_B=sd_log_B,
        q1q3_2025=float(q_now),
        r_hist_mean=r_hist_mean,
        r_hist_sd=r_hist_sd,
        log_r_post_mean=float(post_mean),
        log_r_pred_sd=pred_sd,
        sanity_h1_2025=sanity_h1,
    )


def weighted_quantile(values: np.ndarray, weights: np.ndarray, qs: List[float]) -> np.ndarray:
    values = np.asarray(values, float).reshape(-1)
    weights = np.asarray(weights, float).reshape(-1)
    mask = np.isfinite(values) & np.isfinite(weights) & (weights >= 0)
    v = values[mask]
    w = weights[mask]
    if len(v) == 0:
        return np.array([np.nan] * len(qs))
    order = np.argsort(v)
    v = v[order]
    w = w[order]
    cw = np.cumsum(w)
    if cw[-1] <= 0:
        return np.array([np.nan] * len(qs))
    cw = cw / cw[-1]
    return np.interp(qs, cw, v)


def nowcast_reweight_draws(df_fore: pd.DataFrame, year_anchor: int, mu_log: float, sd_log: float) -> pd.DataFrame:
    draw_col = _find_col(df_fore, ["draw_id", "draw", "sample", "iter"])
    year_col = _find_col(df_fore, ["year"])
    b_col = _find_col(df_fore, ["births", "y", "y_draw", "births_draw"])
    if draw_col is None or year_col is None or b_col is None:
        raise ValueError("Forecast draws must contain draw_id/year/births (or equivalents).")

    tmp = df_fore[[draw_col, year_col, b_col]].copy()
    tmp = tmp.rename(columns={draw_col: "draw_id", year_col: "year", b_col: "births"})
    tmp["births"] = tmp["births"].astype(float)

    anch = tmp[tmp["year"] == year_anchor][["draw_id", "births"]].copy()
    if anch.empty:
        raise ValueError(f"No draws found for anchor year={year_anchor} in forecast draws.")
    anch["logb"] = np.log(np.maximum(anch["births"].values, 1.0))
    z = (anch["logb"].values - mu_log) / sd_log
    logw = -0.5 * z * z
    logw -= np.max(logw)
    w = np.exp(logw)
    w = w / np.sum(w)
    anch["w"] = w
    return tmp.merge(anch[["draw_id", "w"]], on="draw_id", how="inner")


@dataclass
class CalibParams:
    bias_log: float
    scale: float


def _central_interval(log_draws: np.ndarray, p: float) -> Tuple[float, float]:
    lo = float(np.quantile(log_draws, p))
    hi = float(np.quantile(log_draws, 1 - p))
    return lo, hi


def calibrate_by_horizon(df_cases: pd.DataFrame, df_draws: pd.DataFrame, target_cov: float = 0.80, eps: float = 1.0) -> Dict[int, CalibParams]:
    h_col = _find_col(df_cases, ["h", "horizon", "step"])
    y_col = _find_col(df_cases, ["y_true", "truth", "births_true", "births_total", "actual"])
    if h_col is None or y_col is None:
        raise ValueError("Backtest cases must contain horizon and true value columns.")

    if "case_id" in df_cases.columns:
        key_cols = ["case_id"]
    else:
        o_col = _find_col(df_cases, ["origin", "origin_year", "train_end"])
        t_col = _find_col(df_cases, ["target_year", "year_target", "year"])
        if o_col is None or t_col is None:
            raise ValueError("Backtest cases must have case_id or (origin_year,target_year) columns.")
        key_cols = [o_col, t_col]

    h2 = _find_col(df_draws, ["h", "horizon", "step"])
    b2 = _find_col(df_draws, ["births", "y_draw", "y", "births_draw"])
    if h2 is None or b2 is None:
        raise ValueError("Backtest draws must contain horizon and births draw columns.")

    if "case_id" in df_draws.columns and key_cols == ["case_id"]:
        dkey = ["case_id"]
    else:
        o2 = _find_col(df_draws, ["origin", "origin_year", "train_end"])
        t2 = _find_col(df_draws, ["target_year", "year_target", "year"])
        if o2 is None or t2 is None:
            raise ValueError("Backtest draws must have case_id or (origin_year,target_year) columns.")
        dkey = [o2, t2]

    cases = df_cases.copy().rename(columns={h_col: "h", y_col: "y_true"})
    cases["y_true"] = cases["y_true"].astype(float)
    draws = df_draws.copy().rename(columns={h2: "h", b2: "y_draw"})
    merged = draws.merge(cases, left_on=dkey + ["h"], right_on=key_cols + ["h"], how="inner")
    merged["logy"] = np.log(np.maximum(merged["y_true"].values, eps))
    merged["logd"] = np.log(np.maximum(merged["y_draw"].values, eps))

    params: Dict[int, CalibParams] = {}
    p = (1 - target_cov) / 2

    for h in sorted(merged["h"].unique()):
        mh = merged[merged["h"] == h].copy()
        gcols = dkey
        med_pred = mh.groupby(gcols)["logd"].median()
        tru = mh.groupby(gcols)["logy"].first()
        bias = float(np.median(med_pred.values - tru.values))
        mh["logd_bc"] = mh["logd"] - bias

        def cov_for_scale(s: float) -> float:
            covs = []
            for key, sub in mh.groupby(gcols):
                ld = sub["logd_bc"].values
                med = float(np.median(ld))
                adj = med + s * (ld - med)
                lo, hi = _central_interval(adj, p)
                y = float(sub["logy"].iloc[0])
                covs.append(1.0 if (y >= lo and y <= hi) else 0.0)
            return float(np.mean(covs)) if covs else float("nan")

        lo_s, hi_s = 0.05, 5.0
        cov_lo, cov_hi = cov_for_scale(lo_s), cov_for_scale(hi_s)
        if np.isnan(cov_lo) or np.isnan(cov_hi):
            params[int(h)] = CalibParams(bias_log=bias, scale=1.0)
            continue
        if cov_lo >= target_cov:
            best = lo_s
        elif cov_hi <= target_cov:
            best = hi_s
        else:
            best = 1.0
            for _ in range(30):
                mid = 0.5 * (lo_s + hi_s)
                cov_mid = cov_for_scale(mid)
                best = mid
                if cov_mid < target_cov:
                    lo_s = mid
                else:
                    hi_s = mid
        params[int(h)] = CalibParams(bias_log=bias, scale=float(best))
    return params


def apply_calibration_forecast(df_fore: pd.DataFrame, calib_by_h: Dict[int, CalibParams], year_start: int, eps: float = 1.0) -> pd.DataFrame:
    dc = _find_col(df_fore, ["draw_id", "draw", "sample", "iter"])
    yc = _find_col(df_fore, ["year"])
    bc = _find_col(df_fore, ["births", "y", "y_draw", "births_draw"])
    if dc is None or yc is None or bc is None:
        raise ValueError("Forecast draws must contain draw_id/year/births columns.")
    out = df_fore[[dc, yc, bc]].copy().rename(columns={dc: "draw_id", yc: "year", bc: "births"})
    out["births"] = out["births"].astype(float)
    out["h"] = (out["year"].astype(int) - int(year_start) + 1).astype(int)
    out["logb"] = np.log(np.maximum(out["births"].values, eps))

    chunks = []
    for y, sub in out.groupby("year"):
        h = int(sub["h"].iloc[0])
        cp = calib_by_h.get(h, CalibParams(0.0, 1.0))
        ld = sub["logb"].values - cp.bias_log
        med = float(np.median(ld))
        ld_adj = med + cp.scale * (ld - med)
        chunks.append(pd.DataFrame({"draw_id": sub["draw_id"].values, "year": int(y), "births": np.exp(ld_adj)}))
    return pd.concat(chunks, ignore_index=True)


def pinball_loss(y: float, q: float, tau: float) -> float:
    return (tau - (1.0 if y < q else 0.0)) * (y - q)


def optimize_weights_grid(per_draws: Dict[str, pd.DataFrame], per_cases: Dict[str, pd.DataFrame], model_names: List[str], tau: float, h: int, step: float = 0.05, floor_struct: Optional[float] = None) -> Dict[str, float]:
    # normalize cases
    def norm_cases(df: pd.DataFrame) -> pd.DataFrame:
        hc = _find_col(df, ["h", "horizon", "step"])
        yc = _find_col(df, ["y_true", "truth", "births_true", "births_total", "actual"])
        if hc is None or yc is None:
            raise ValueError("cases missing horizon/y_true")
        out = df.copy().rename(columns={hc: "h", yc: "y_true"})
        if "case_id" in out.columns:
            out["key"] = out["case_id"].apply(lambda x: (x,))
        else:
            oc = _find_col(out, ["origin", "origin_year", "train_end"])
            tc = _find_col(out, ["target_year", "year_target", "year"])
            if oc is None or tc is None:
                raise ValueError("cases need case_id or origin/target")
            out["key"] = list(map(tuple, out[[oc, tc]].values.tolist()))
        return out[out["h"] == h][["key", "y_true"]].drop_duplicates()

    def norm_draws(df: pd.DataFrame) -> pd.DataFrame:
        hc = _find_col(df, ["h", "horizon", "step"])
        bc = _find_col(df, ["births", "y_draw", "y", "births_draw"])
        if hc is None or bc is None:
            raise ValueError("draws missing horizon/births")
        out = df.copy().rename(columns={hc: "h", bc: "y_draw"})
        if "case_id" in out.columns:
            out["key"] = out["case_id"].apply(lambda x: (x,))
        else:
            oc = _find_col(out, ["origin", "origin_year", "train_end"])
            tc = _find_col(out, ["target_year", "year_target", "year"])
            if oc is None or tc is None:
                raise ValueError("draws need case_id or origin/target")
            out["key"] = list(map(tuple, out[[oc, tc]].values.tolist()))
        return out[out["h"] == h][["key", "y_draw"]]

    cases_m = {m: norm_cases(per_cases[m]) for m in model_names}
    keys = set(cases_m[model_names[0]]["key"])
    for m in model_names[1:]:
        keys &= set(cases_m[m]["key"])
    keys = sorted(list(keys))
    if not keys:
        raise ValueError(f"No overlapping cases across models for h={h}")

    truth = {k: float(cases_m[model_names[0]].set_index("key").loc[k, "y_true"]) for k in keys}

    draws_m = {m: norm_draws(per_draws[m]) for m in model_names}
    per_case = {m: {k: draws_m[m][draws_m[m]["key"] == k]["y_draw"].astype(float).values for k in keys} for m in model_names}

    def eval_w(w):
        losses=[]
        for k in keys:
            y = truth[k]
            vals=[]; wts=[]
            for m in model_names:
                arr = per_case[m][k]
                vals.append(arr)
                wts.append(np.full(arr.shape, w[m]/len(arr), dtype=float))
            vv=np.concatenate(vals); ww=np.concatenate(wts)
            q=float(weighted_quantile(vv, ww, [tau])[0])
            losses.append(pinball_loss(y,q,tau))
        return float(np.mean(losses))

    a,b,c = model_names
    best=None; best_obj=float("inf")
    for wa in np.arange(0,1+1e-9,step):
        for wb in np.arange(0,1-wa+1e-9,step):
            wc=1-wa-wb
            if wc < -1e-9: 
                continue
            w={a:float(wa), b:float(wb), c:float(wc)}
            if floor_struct is not None and w["struct"] + 1e-12 < floor_struct:
                continue
            obj=eval_w(w)
            if obj < best_obj:
                best_obj=obj; best=w
    if best is None:
        raise RuntimeError("No feasible weights found")
    return best


def forecast_quantiles(df_fore_w: pd.DataFrame, qs: List[float]) -> pd.DataFrame:
    out=[]
    for y, sub in df_fore_w.groupby("year"):
        vals=sub["births"].astype(float).values
        wts=sub["w"].astype(float).values
        qv=weighted_quantile(vals,wts,qs)
        row={"year":int(y)}
        for q,v in zip(qs,qv):
            row[f"q{int(round(q*100)):02d}"]=float(v)
        out.append(row)
    return pd.DataFrame(out).sort_values("year")


def ensemble_quantiles(model_forecasts: Dict[str, pd.DataFrame], weights_by_h: Dict[int, Dict[str,float]], year_start: int, qs: List[float]) -> pd.DataFrame:
    years = sorted(set(next(iter(model_forecasts.values()))["year"].unique().tolist()))
    out=[]
    for y in years:
        h=int(y-year_start+1)
        w_h=weights_by_h[h]
        vals_all=[]; wts_all=[]
        for m, dfm in model_forecasts.items():
            sub=dfm[dfm["year"]==y]
            vals=sub["births"].astype(float).values
            wt=sub["w"].astype(float).values
            wt = wt / np.sum(wt)
            vals_all.append(vals)
            wts_all.append(w_h[m]*wt)
        vv=np.concatenate(vals_all); ww=np.concatenate(wts_all)
        qv=weighted_quantile(vv,ww,qs)
        row={"year":int(y)}
        for q,v in zip(qs,qv):
            row[f"q{int(round(q*100)):02d}"]=float(v)
        out.append(row)
    return pd.DataFrame(out).sort_values("year")


def plot_fan_chart(annual_df: pd.DataFrame, fq: pd.DataFrame, title: str, out_png: str, plan_col: str):
    _ensure_dir(os.path.dirname(out_png))
    x_hist = annual_df["year"].to_numpy(dtype=int)
    y_hist = annual_df["births_total"].to_numpy(dtype=float)
    x = fq["year"].to_numpy(dtype=int)

    y05 = fq["q05"].to_numpy(dtype=float)
    y95 = fq["q95"].to_numpy(dtype=float)
    y50 = fq["q50"].to_numpy(dtype=float)
    ypl = fq[plan_col].to_numpy(dtype=float)

    plt.figure(figsize=(12,6))
    plt.plot(x_hist, y_hist, label="Skutečnost (ČSÚ)")
    plt.fill_between(x, y05, y95, alpha=0.25, label="5–95 %")
    plt.plot(x, y50, linestyle="--", label="Medián (50 %)")
    plt.plot(x, ypl, linestyle=":", label=f"Plánovací kvantil ({plan_col})")
    plt.title(title)
    plt.xlabel("Rok")
    plt.ylabel("Počet živě narozených")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--annual_csv", required=True)
    ap.add_argument("--quarters_xlsx", required=True)
    ap.add_argument("--year_now", type=int, default=2025)
    ap.add_argument("--sd_log", type=float, default=0.04)

    ap.add_argument("--v4_forecast", required=True)
    ap.add_argument("--v4_cases", required=True)
    ap.add_argument("--v4_draws", required=True)

    ap.add_argument("--v38_forecast", required=True)
    ap.add_argument("--v38_cases", required=True)
    ap.add_argument("--v38_draws", required=True)

    ap.add_argument("--struct_forecast", required=True)
    ap.add_argument("--struct_cases", required=True)
    ap.add_argument("--struct_draws", required=True)

    ap.add_argument("--forecast_start", type=int, default=2025)
    ap.add_argument("--H", type=int, default=5)
    ap.add_argument("--target_cov", type=float, default=0.80)
    ap.add_argument("--tau", type=float, default=0.8333)
    ap.add_argument("--grid_step", type=float, default=0.05)
    ap.add_argument("--floor_struct", type=float, default=0.10)
    ap.add_argument("--outdir", default="runs/ensemble_out")

    args = ap.parse_args()
    _ensure_dir(args.outdir)

    annual = pd.read_csv(args.annual_csv)
    ycol = _find_col(annual, ["births_total", "births", "y"])
    if ycol is None:
        raise ValueError("annual_csv must include births_total (or similar).")
    annual = annual.rename(columns={ycol:"births_total"})
    annual["births_total"] = annual["births_total"].astype(float)

    qdf = load_quarterly_births_xlsx(args.quarters_xlsx)
    now = compute_nowcast_from_quarters(qdf, args.year_now, args.sd_log)
    with open(os.path.join(args.outdir,"nowcast_2025_summary.json"),"w",encoding="utf-8") as f:
        json.dump(now.__dict__, f, ensure_ascii=False, indent=2)

    # Load backtest and calibrate v4 + structural
    v4_cases = _read_any(args.v4_cases)
    v4_draws = _read_any(args.v4_draws)
    v4_cal = calibrate_by_horizon(v4_cases, v4_draws, target_cov=args.target_cov)

    st_cases = _read_any(args.struct_cases)
    st_draws = _read_any(args.struct_draws)
    st_cal = calibrate_by_horizon(st_cases, st_draws, target_cov=args.target_cov)

    calib_rows=[]
    for h in range(1,args.H+1):
        v=v4_cal.get(h, CalibParams(0.0,1.0))
        s=st_cal.get(h, CalibParams(0.0,1.0))
        calib_rows.append({"model":"v4","h":h,"bias_log":v.bias_log,"scale":v.scale})
        calib_rows.append({"model":"struct","h":h,"bias_log":s.bias_log,"scale":s.scale})
    pd.DataFrame(calib_rows).to_csv(os.path.join(args.outdir,"calibration_params_by_h.csv"), index=False)

    # Load forecast draws
    v4_fore = _read_any(args.v4_forecast)
    v38_fore = _read_any(args.v38_forecast)
    st_fore = _read_any(args.struct_forecast)

    # Apply calibration to forecast (v4 + structural)
    v4_fore_cal = apply_calibration_forecast(v4_fore, v4_cal, args.forecast_start)
    st_fore_cal = apply_calibration_forecast(st_fore, st_cal, args.forecast_start)

    # Normalize v3.8 forecast columns
    dc = _find_col(v38_fore, ["draw_id","draw","sample","iter"])
    yc = _find_col(v38_fore, ["year"])
    bc = _find_col(v38_fore, ["births","y","y_draw"])
    if dc is None or yc is None or bc is None:
        raise ValueError("v3.8 forecast draws must include draw_id/year/births")
    v38_fore = v38_fore.rename(columns={dc:"draw_id", yc:"year", bc:"births"})
    v38_fore["births"] = v38_fore["births"].astype(float)

    # Nowcast conditioning
    v4_w = nowcast_reweight_draws(v4_fore_cal, args.year_now, now.mu_log_B, now.sd_log_B)
    v38_w = nowcast_reweight_draws(v38_fore, args.year_now, now.mu_log_B, now.sd_log_B)
    st_w = nowcast_reweight_draws(st_fore_cal, args.year_now, now.mu_log_B, now.sd_log_B)

    # Optimize weights by horizon
    per_cases = {"v4": v4_cases, "v38": _read_any(args.v38_cases), "struct": st_cases}
    per_draws = {"v4": v4_draws, "v38": _read_any(args.v38_draws), "struct": st_draws}
    model_names = ["v4","v38","struct"]

    weights_floor={}
    weights_pure={}
    for h in range(1,args.H+1):
        weights_pure[h] = optimize_weights_grid(per_draws, per_cases, model_names, args.tau, h, step=args.grid_step, floor_struct=None)
        weights_floor[h] = optimize_weights_grid(per_draws, per_cases, model_names, args.tau, h, step=args.grid_step, floor_struct=args.floor_struct)

    def weights_df(w_by_h):
        rows=[]
        for h,w in w_by_h.items():
            row={"h":h}; row.update(w); rows.append(row)
        return pd.DataFrame(rows).sort_values("h")

    weights_df(weights_pure).to_csv(os.path.join(args.outdir,"ensemble_weights_by_h_pure.csv"), index=False)
    weights_df(weights_floor).to_csv(os.path.join(args.outdir,"ensemble_weights_by_h_floor_struct.csv"), index=False)

    # Quantiles and plots
    qs=[0.05, 0.50, 0.95, args.tau]
    q_map={0.05:"q05", 0.50:"q50", 0.95:"q95", args.tau:"q_plan"}

    v4_q = forecast_quantiles(v4_w, qs).rename(columns={f"q{int(round(q*100)):02d}":q_map[q] for q in qs})
    v38_q = forecast_quantiles(v38_w, qs).rename(columns={f"q{int(round(q*100)):02d}":q_map[q] for q in qs})
    st_q = forecast_quantiles(st_w, qs).rename(columns={f"q{int(round(q*100)):02d}":q_map[q] for q in qs})

    model_forecasts={
        "v4": v4_w[["draw_id","year","births","w"]],
        "v38": v38_w[["draw_id","year","births","w"]],
        "struct": st_w[["draw_id","year","births","w"]],
    }
    ens_q = ensemble_quantiles(model_forecasts, weights_floor, args.forecast_start, qs).rename(columns={f"q{int(round(q*100)):02d}":q_map[q] for q in qs})

    # Save combined table
    out = v4_q.merge(v38_q, on="year", suffixes=("_v4","_v38")).merge(st_q, on="year")
    # add suffix for struct cols
    for c in list(out.columns):
        if c.startswith("q") and not (c.endswith("_v4") or c.endswith("_v38")) and c != "year":
            out = out.rename(columns={c: c+"_struct"})
    out = out.merge(ens_q, on="year", how="left", suffixes=("","_ens"))
    out.to_csv(os.path.join(args.outdir,"forecast_quantiles_all_models.csv"), index=False)

    plot_fan_chart(annual, v4_q, "v4 UA proxy (nowcast + calib) – fan-chart", os.path.join(args.outdir,"fan_v4_nowcast.png"), plan_col="q_plan")
    plot_fan_chart(annual, v38_q, "v3.8 PIT-cal (nowcast) – fan-chart", os.path.join(args.outdir,"fan_v38_nowcast.png"), plan_col="q_plan")
    plot_fan_chart(annual, st_q, "Strukturální věkový model (nowcast + calib) – fan-chart", os.path.join(args.outdir,"fan_struct_nowcast.png"), plan_col="q_plan")
    plot_fan_chart(annual, ens_q, "Ensemble (floor struct) (nowcast + calib) – fan-chart", os.path.join(args.outdir,"fan_ensemble_nowcast.png"), plan_col="q_plan")

    print("[OK] Done. Outputs:", args.outdir)
    print("[INFO] Nowcast median B2025 ≈", float(np.exp(now.mu_log_B)))
    print("[INFO] Sanity H1 2025 (from xlsx):", now.sanity_h1_2025)


if __name__ == "__main__":
    main()
