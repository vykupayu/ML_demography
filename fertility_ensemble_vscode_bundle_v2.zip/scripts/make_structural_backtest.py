import argparse
import os
from pathlib import Path
import numpy as np
import pandas as pd


def ensure_dir(p: str):
    Path(p).mkdir(parents=True, exist_ok=True)


def annual_births_from_panel(panel_csv: str) -> pd.DataFrame:
    """
    panel expected to contain at least: year, births (or births_total), age
    We'll aggregate to annual total births.
    """
    df = pd.read_csv(panel_csv)
    ycol = None
    for c in df.columns:
        if c.lower() == "year":
            ycol = c
            break
    if ycol is None:
        raise ValueError("panel must contain column 'year'")
    bcol = None
    for cand in ["births_total", "births", "B", "Ba", "count"]:
        for c in df.columns:
            if cand.lower() == c.lower():
                bcol = c
                break
        if bcol:
            break
    if bcol is None:
        # fallback: any column containing 'birth'
        for c in df.columns:
            if "birth" in c.lower():
                bcol = c
                break
    if bcol is None:
        raise ValueError("panel must contain births column (births_total/births/...)")
    annual = df.groupby(ycol)[bcol].sum().reset_index().rename(columns={ycol:"year", bcol:"births_total"})
    annual["year"] = annual["year"].astype(int)
    annual["births_total"] = annual["births_total"].astype(float)
    return annual.sort_values("year")


def simulate_local_level(logy: np.ndarray, H: int, n_draws: int, sigma: float, drift: float = 0.0, seed: int = 123) -> np.ndarray:
    """
    Local-level / RW with drift on log scale:
      x_{t+1} = x_t + drift + eps, eps~N(0,sigma^2)
    Returns draws shape (n_draws, H)
    """
    rng = np.random.default_rng(seed)
    x0 = float(logy[-1])
    eps = rng.normal(0.0, sigma, size=(n_draws, H))
    steps = drift + eps
    x = x0 + np.cumsum(steps, axis=1)
    return x


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["surrogate","call_model"], default="surrogate",
                    help="surrogate: fast rolling backtest using local-level model on annual totals; call_model: optional, if your structural script supports train_end.")
    ap.add_argument("--panel", required=True, help="panel CSV used by structural model (age-year) OR fertility_panel_v3.csv")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--H", type=int, default=5)
    ap.add_argument("--origin_min", type=int, default=2012)
    ap.add_argument("--origin_max", type=int, default=2018)
    ap.add_argument("--n_draws", type=int, default=800)
    ap.add_argument("--seed", type=int, default=123)

    # call_model params (optional)
    ap.add_argument("--struct_script", default="")
    ap.add_argument("--exp_forward", default="")
    ap.add_argument("--exp_projection", default="")

    args = ap.parse_args()
    ensure_dir(args.outdir)

    annual = annual_births_from_panel(args.panel)

    if args.mode == "call_model":
        raise NotImplementedError(
            "call_model mode is intentionally disabled in the bundle, because structural scripts differ by version. "
            "Use surrogate mode for presentation, and run your full structural rolling backtest separately if needed."
        )

    # surrogate mode: use local-level on log annual births
    years = annual["year"].values
    y = annual["births_total"].values
    logy = np.log(np.maximum(y, 1.0))

    # Estimate sigma from 1-step log differences (robust)
    d = np.diff(logy)
    sigma = float(np.median(np.abs(d - np.median(d))) / 0.6745)  # MAD -> sd
    if not np.isfinite(sigma) or sigma <= 0:
        sigma = float(np.std(d, ddof=1))
    drift = float(np.median(d))

    cases_rows = []
    draws_rows = []

    for origin in range(args.origin_min, args.origin_max + 1):
        # training up to origin
        if origin not in years:
            continue
        train_mask = years <= origin
        idx = np.where(train_mask)[0]
        if len(idx) < 5:
            continue
        logy_train = logy[idx]

        # simulate
        x_draws = simulate_local_level(logy_train, args.H, args.n_draws, sigma=sigma, drift=drift, seed=args.seed + origin)

        for h in range(1, args.H + 1):
            target = origin + h
            # truth if exists
            truth_row = annual[annual["year"] == target]
            if truth_row.empty:
                continue
            y_true = float(truth_row["births_total"].iloc[0])

            case_id = f"struct_{origin}_h{h}"
            cases_rows.append({
                "case_id": case_id,
                "origin_year": origin,
                "target_year": target,
                "h": h,
                "y_true": y_true
            })

            births_draws = np.exp(x_draws[:, h-1])
            for i, val in enumerate(births_draws):
                draws_rows.append({
                    "case_id": case_id,
                    "origin_year": origin,
                    "target_year": target,
                    "h": h,
                    "draw_id": i,
                    "births": float(val)
                })

    cases = pd.DataFrame(cases_rows)
    draws = pd.DataFrame(draws_rows)

    cases.to_csv(os.path.join(args.outdir, "backtest_cases.csv"), index=False)
    draws.to_csv(os.path.join(args.outdir, "backtest_draws_long.csv.gz"), index=False, compression="gzip")

    meta = {
        "mode": args.mode,
        "sigma_log": sigma,
        "drift_log": drift,
        "n_draws": args.n_draws,
        "origin_min": args.origin_min,
        "origin_max": args.origin_max,
        "H": args.H,
    }
    with open(os.path.join(args.outdir, "backtest_meta.json"), "w", encoding="utf-8") as f:
        import json
        json.dump(meta, f, indent=2, ensure_ascii=False)

    print("[OK] Structural backtest created (surrogate).")
    print("[OK] outdir:", args.outdir)


if __name__ == "__main__":
    main()
