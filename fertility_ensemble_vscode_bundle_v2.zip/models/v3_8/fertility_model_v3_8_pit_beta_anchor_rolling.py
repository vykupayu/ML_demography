#%%
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v3.8 – Parsimonious rolling SSM for births_total with:
- damped local-linear-trend (phi<1)
- exogenous regressors with z-scoring (per training window)
- process variances anchored from pre-2020
- rolling backtest (h=1..H) saving full draws
- calibration by horizon: bias + width scaling (CAN shrink or inflate)
- optional PIT calibration by horizon via Beta fit (shrunken for small n)

Dependencies: numpy, pandas, scipy, matplotlib
"""
from __future__ import annotations

import argparse
import os
import sys
import math
import gzip
from dataclasses import dataclass
from typing import Dict, Tuple, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import beta as beta_dist


# ----------------------------
# Utilities
# ----------------------------

def _ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def zscore_fit(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    mu = np.nanmean(X, axis=0)
    sd = np.nanstd(X, axis=0, ddof=0)
    sd = np.where(sd < 1e-12, 1.0, sd)
    return mu, sd

def zscore_apply(X: np.ndarray, mu: np.ndarray, sd: np.ndarray) -> np.ndarray:
    return (X - mu) / sd

def soft_threshold(rho: float, lam: float) -> float:
    if rho > lam:
        return rho - lam
    if rho < -lam:
        return rho + lam
    return 0.0

def lasso_cd(X: np.ndarray, y: np.ndarray, lam: float, n_iter: int = 500) -> np.ndarray:
    """
    Coordinate descent for LASSO with standardized columns (mean 0, var 1).
    Minimizes 0.5||y - Xb||^2 + lam*||b||_1.
    """
    n, p = X.shape
    b = np.zeros(p, dtype=float)
    Xy = X.T @ y
    X2 = np.sum(X * X, axis=0)
    X2 = np.where(X2 < 1e-12, 1.0, X2)

    r = y - X @ b
    for _ in range(n_iter):
        for j in range(p):
            # add back contribution of feature j
            r = r + X[:, j] * b[j]
            rho = X[:, j].T @ r
            b[j] = soft_threshold(rho, lam) / X2[j]
            # remove updated contribution
            r = r - X[:, j] * b[j]
    return b


# ----------------------------
# Damped LLT Kalman smoother
# ----------------------------

@dataclass
class SSMParams:
    sig_y: float
    sig_level: float
    sig_slope: float
    phi: float

def kalman_smoother_damped(y: np.ndarray, X: np.ndarray, beta: np.ndarray, params: SSMParams):
    """
    2D state: [level, slope]
    level_t = level_{t-1} + slope_{t-1} + eta_t
    slope_t = phi*slope_{t-1} + zeta_t
    y_t = level_t + X_t beta + eps_t
    """
    T = y.shape[0]
    y_tilde = y - X @ beta

    F = np.array([[1.0, 1.0],
                  [0.0, params.phi]], dtype=float)
    H = np.array([[1.0, 0.0]], dtype=float)  # 1x2
    Q = np.array([[params.sig_level**2, 0.0],
                  [0.0, params.sig_slope**2]], dtype=float)
    R = params.sig_y**2

    # priors
    a = np.zeros(2, dtype=float)
    P = np.eye(2, dtype=float) * (10.0 * R + 1.0)

    # store
    a_filt = np.zeros((T, 2))
    P_filt = np.zeros((T, 2, 2))
    a_pred = np.zeros((T, 2))
    P_pred = np.zeros((T, 2, 2))

    I2 = np.eye(2, dtype=float)

    for t in range(T):
        # predict
        a = F @ a
        P = F @ P @ F.T + Q

        a_pred[t] = a
        P_pred[t] = P

        # update
        v = y_tilde[t] - (H @ a)[0]
        S = (H @ P @ H.T)[0, 0] + R
        K = (P @ H.T)[:, 0] / max(S, 1e-12)

        a = a + K * v
        P = (I2 - np.outer(K, H[0])) @ P

        # symmetrize, jitter
        P = 0.5 * (P + P.T)
        eigmin = np.min(np.linalg.eigvalsh(P))
        if eigmin < 1e-10:
            P = P + np.eye(2) * (1e-10 - eigmin)

        a_filt[t] = a
        P_filt[t] = P

    # RTS smoother
    a_smooth = np.zeros((T, 2))
    P_smooth = np.zeros((T, 2, 2))

    a_smooth[-1] = a_filt[-1]
    P_smooth[-1] = P_filt[-1]

    for t in range(T - 2, -1, -1):
        Pp = P_pred[t + 1]
        # J = P_filt[t] F' Pp^{-1}
        J = P_filt[t] @ F.T @ np.linalg.inv(Pp)
        a_smooth[t] = a_filt[t] + J @ (a_smooth[t + 1] - a_pred[t + 1])
        P_smooth[t] = P_filt[t] + J @ (P_smooth[t + 1] - Pp) @ J.T

        P_smooth[t] = 0.5 * (P_smooth[t] + P_smooth[t].T)
        eigmin = np.min(np.linalg.eigvalsh(P_smooth[t]))
        if eigmin < 1e-10:
            P_smooth[t] = P_smooth[t] + np.eye(2) * (1e-10 - eigmin)

    return a_smooth, P_smooth, a_filt, P_filt


def fit_em_lasso(y: np.ndarray, X_raw: np.ndarray, params: SSMParams, lasso_lambda: float,
                 em_iter: int = 10, cd_iter: int = 800):
    """
    Simple EM-like alternating updates:
      beta <- lasso( y - level_hat ~ X )
      states <- smoother( y - X beta )
    X is z-scored inside (returns beta in z-score space + scales).
    """
    # z-score X (per fit)
    mu, sd = zscore_fit(X_raw)
    X = zscore_apply(X_raw, mu, sd)
    X = np.nan_to_num(X, nan=0.0)

    beta = np.zeros(X.shape[1], dtype=float)

    for _ in range(em_iter):
        a_smooth, P_smooth, *_ = kalman_smoother_damped(y, X, beta, params)
        level = a_smooth[:, 0]
        resid = y - level
        beta = lasso_cd(X, resid, lam=lasso_lambda, n_iter=cd_iter)

    # final smoother
    a_smooth, P_smooth, a_filt, P_filt = kalman_smoother_damped(y, X, beta, params)
    return {
        "beta_z": beta,
        "X_mu": mu,
        "X_sd": sd,
        "state_mean": a_smooth,
        "state_cov": P_smooth,
        "filt_last_mean": a_filt[-1].copy(),
        "filt_last_cov": P_filt[-1].copy(),
        "params": params,
    }


def simulate_forecast_draws(rng: np.random.Generator,
                            fit: dict,
                            X_future_raw: np.ndarray,
                            years_future: np.ndarray,
                            variant: str,
                            n_draws: int,
                            y_floor: float = 0.0):
    """
    Returns DataFrame long draws:
      variant, target_year, draw_id, births_draw
    """
    beta = fit["beta_z"]
    mu = fit["X_mu"]
    sd = fit["X_sd"]
    params: SSMParams = fit["params"]

    # z-score future X with training scaling
    Xf = zscore_apply(X_future_raw, mu, sd)
    Xf = np.nan_to_num(Xf, nan=0.0)

    F = np.array([[1.0, 1.0],
                  [0.0, params.phi]], dtype=float)
    Q = np.array([[params.sig_level**2, 0.0],
                  [0.0, params.sig_slope**2]], dtype=float)

    # initial state ~ N(m_T, P_T)
    m0 = fit["filt_last_mean"]
    P0 = fit["filt_last_cov"]
    P0 = 0.5 * (P0 + P0.T)
    # jitter
    eigmin = np.min(np.linalg.eigvalsh(P0))
    if eigmin < 1e-10:
        P0 = P0 + np.eye(2) * (1e-10 - eigmin)

    states0 = rng.multivariate_normal(mean=m0, cov=P0, size=n_draws)

    if variant == "t":
        nu = 7.0  # fixed (parsimonious)
        scale = params.sig_y * math.sqrt((nu - 2.0) / nu)
    else:
        nu = None
        scale = None

    out_rows = []
    H = years_future.shape[0]
    for i in range(n_draws):
        s = states0[i].copy()
        for h in range(H):
            # state evolve
            noise = rng.multivariate_normal(mean=np.zeros(2), cov=Q)
            s = F @ s + noise
            mean_y = s[0] + float(Xf[h] @ beta)

            if variant == "t":
                eps = scale * rng.standard_t(df=nu)
            else:
                eps = params.sig_y * rng.standard_normal()

            y_sim = mean_y + eps
            if y_floor is not None:
                y_sim = max(y_floor, y_sim)

            out_rows.append((variant, int(years_future[h]), i, float(y_sim)))

    return pd.DataFrame(out_rows, columns=["variant", "target_year", "draw_id", "births_draw"])


# ----------------------------
# Calibration helpers
# ----------------------------

def summarize_draws_to_cases(draws: pd.DataFrame, y_true_by_year: Dict[int, float], last_train_year_by_origin: Dict[int, int]):
    """
    Expects draws for backtest with columns: origin_year, variant, target_year, draw_id, births_draw, h.
    Returns cases table with q10,q50,q90 and y_true.
    """
    grp_cols = ["variant", "origin_year", "h", "target_year"]
    def _qs(g: pd.DataFrame) -> pd.Series:
        x = g["births_draw"].to_numpy()
        return pd.Series({
            "q10": float(np.quantile(x, 0.10)),
            "q50": float(np.quantile(x, 0.50)),
            "q90": float(np.quantile(x, 0.90)),
        })
    qs = draws.groupby(grp_cols, sort=False).apply(_qs).reset_index()
    qs["y_true"] = qs["target_year"].map(y_true_by_year).astype(float)
    qs["train_last_year"] = qs["origin_year"].map(last_train_year_by_origin).astype(int)
    return qs
def solve_width_scale(cases: pd.DataFrame, target_cov: float = 0.8, s_lo: float = 0.2, s_hi: float = 3.0, n_iter: int = 40) -> float:
    """
    Find s so that coverage of interval [q50 + s*(q10-q50), q50 + s*(q90-q50)] hits target_cov.
    """
    y = cases["y_true"].to_numpy()
    q10 = cases["q10"].to_numpy()
    q50 = cases["q50"].to_numpy()
    q90 = cases["q90"].to_numpy()

    def cov(s: float) -> float:
        lo = q50 + s * (q10 - q50)
        hi = q50 + s * (q90 - q50)
        return float(np.mean((y >= lo) & (y <= hi)))

    lo, hi = s_lo, s_hi
    c_lo, c_hi = cov(lo), cov(hi)

    # if monotone doesn't bracket, clamp
    if c_lo >= target_cov:
        return lo
    if c_hi <= target_cov:
        return hi

    for _ in range(n_iter):
        mid = 0.5 * (lo + hi)
        c_mid = cov(mid)
        if c_mid < target_cov:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def fit_bias_scale_by_horizon(cases: pd.DataFrame, target_cov: float = 0.8, shrink_k: float = 20.0):
    rows = []
    for (variant, h), g in cases.groupby(["variant", "h"], sort=False):
        n = g.shape[0]
        w = n / (n + shrink_k)
        bias = float(np.mean(g["q50"] - g["y_true"]))
        bias = w * bias  # shrink to 0

        # bias-corrected temporary q's
        g2 = g.copy()
        g2["q10"] = g2["q10"] - bias
        g2["q50"] = g2["q50"] - bias
        g2["q90"] = g2["q90"] - bias

        s_est = solve_width_scale(g2, target_cov=target_cov)
        s = w * s_est + (1.0 - w) * 1.0  # shrink to 1

        rows.append((variant, int(h), n, bias, s))
    return pd.DataFrame(rows, columns=["variant", "h", "n_cases", "bias", "width_scale"])


def apply_bias_scale_to_draws(draws: pd.DataFrame, bias_scale: pd.DataFrame):
    """
    draws: columns variant, origin_year(optional), h(optional), target_year, draw_id, births_draw
    We need per (variant,h) bias and width_scale and per (variant,origin_year,target_year) median for centering.
    We'll center by per-case median from draws.
    """
    out = draws.copy()
    # compute per-case median
    key_cols = ["variant", "target_year"]
    if "origin_year" in out.columns:
        key_cols = ["variant", "origin_year", "h", "target_year"]
    med = out.groupby(key_cols, sort=False)["births_draw"].median().reset_index().rename(columns={"births_draw": "med"})
    out = out.merge(med, on=key_cols, how="left")
    out = out.merge(bias_scale[["variant", "h", "bias", "width_scale"]], on=["variant", "h"], how="left")
    out["bias"] = out["bias"].fillna(0.0)
    out["width_scale"] = out["width_scale"].fillna(1.0)

    # apply: shift by -bias, scale deviations from median
    out["births_draw_cal"] = (out["births_draw"] - out["med"]) * out["width_scale"] + (out["med"] - out["bias"])
    return out


def compute_pit_values(backtest_draws_cal: pd.DataFrame, y_true_by_year: Dict[int, float]) -> pd.DataFrame:
    """
    For each (variant, origin_year, h, target_year): PIT = P(draw<=y_true)
    """
    df = backtest_draws_cal.copy()
    df["y_true"] = df["target_year"].map(y_true_by_year).astype(float)

    def pit_group(g: pd.DataFrame) -> float:
        y = float(g["y_true"].iloc[0])
        x = g["births_draw_cal"].to_numpy()
        return float(np.mean(x <= y))

    pits = df.groupby(["variant", "h", "origin_year", "target_year"], sort=False).apply(pit_group).reset_index(name="pit")
    return pits


def fit_beta_pit_by_horizon(pits: pd.DataFrame, shrink_k: float = 20.0) -> pd.DataFrame:
    rows = []
    for (variant, h), g in pits.groupby(["variant", "h"], sort=False):
        u = g["pit"].to_numpy()
        n = u.size
        if n < 3:
            rows.append((variant, int(h), n, 1.0, 1.0))
            continue
        m = float(np.mean(u))
        v = float(np.var(u, ddof=1))

        # MoM for Beta
        denom = m * (1.0 - m)
        if denom <= 1e-9 or v <= 1e-9 or v >= denom:
            a, b = 1.0, 1.0
        else:
            k = denom / v - 1.0
            a = max(1e-3, m * k)
            b = max(1e-3, (1.0 - m) * k)

        # shrink toward uniform for small n
        w = n / (n + shrink_k)
        a = w * a + (1.0 - w) * 1.0
        b = w * b + (1.0 - w) * 1.0
        rows.append((variant, int(h), n, float(a), float(b)))
    return pd.DataFrame(rows, columns=["variant", "h", "n_cases", "beta_a", "beta_b"])


def apply_pit_beta_to_forecast_draws(forecast_draws_cal: pd.DataFrame, beta_params: pd.DataFrame, last_hist_year: int):
    """
    For each target_year -> horizon h=target_year-last_hist_year:
      - compute ranks u in (0,1)
      - map u' = BetaPPF(u; a,b) (acts like H^{-1})
      - output draw_pitcal = empirical_quantile(draws_cal, u')
    """
    out = forecast_draws_cal.copy()
    out["h"] = out["target_year"].astype(int) - int(last_hist_year)

    pmap = {(r.variant, int(r.h)): (float(r.beta_a), float(r.beta_b)) for r in beta_params.itertuples(index=False)}
    out["births_draw_pitcal"] = np.nan

    for (variant, target_year), g in out.groupby(["variant", "target_year"], sort=False):
        h = int(target_year) - int(last_hist_year)
        a, b = pmap.get((variant, h), (1.0, 1.0))
        x = g["births_draw_cal"].to_numpy()
        order = np.argsort(x)
        xs = x[order]
        n = xs.size
        # ranks in (0,1)
        u = (np.arange(n) + 0.5) / n
        u_adj = beta_dist.ppf(u, a, b)
        u_adj = np.clip(u_adj, 1e-6, 1 - 1e-6)
        # map to indices
        idx = np.minimum(n - 1, np.floor(u_adj * n).astype(int))
        xp = xs[idx]
        # put back to original order
        inv = np.empty_like(order)
        inv[order] = np.arange(n)
        out.loc[g.index, "births_draw_pitcal"] = xp[inv]

    return out


# ----------------------------
# Backtest + Forecast
# ----------------------------

def build_future_features(annual: pd.DataFrame, feature_cols: List[str], years_future: np.ndarray,
                          war_start_year: int = 2022, war_decay_rho: float = 0.6) -> np.ndarray:
    """
    Construct X for future years:
      - take last observed value for most features
      - recompute war_decay deterministically
    """
    last = annual.sort_values("year").iloc[-1]
    Xf = []
    for yr in years_future:
        row = {}
        for c in feature_cols:
            if c == "war_decay":
                if yr < war_start_year:
                    row[c] = 0.0
                else:
                    row[c] = float(war_decay_rho ** (int(yr) - war_start_year))
            else:
                row[c] = float(last.get(c, np.nan))
        Xf.append([row[c] for c in feature_cols])
    return np.array(Xf, dtype=float)


def run_rolling_backtest(annual: pd.DataFrame, feature_cols: List[str], params: SSMParams,
                         window: int, H: int, n_draws: int, lasso_lambda: float, seed: int,
                         outdir: str) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[int, float]]:
    rng = np.random.default_rng(seed)

    annual = annual.sort_values("year").reset_index(drop=True)
    years = annual["year"].astype(int).to_numpy()
    y_by_year = {int(r.year): float(r.births_total) for r in annual.itertuples(index=False)}

    rows_draws = []
    last_train_year_by_origin = {}

    for i in range(window - 1, len(years) - 1):
        origin_year = int(years[i])
        train_years = years[i - window + 1:i + 1]
        test_years = years[i + 1:i + 1 + H]
        test_years = test_years[test_years <= years[-1]]
        if test_years.size == 0:
            continue

        train = annual[annual["year"].isin(train_years)]
        test = annual[annual["year"].isin(test_years)]

        y_train = train["births_total"].to_numpy(dtype=float)
        X_train = train[feature_cols].to_numpy(dtype=float)
        fit = fit_em_lasso(y_train, X_train, params, lasso_lambda=lasso_lambda)

        last_train_year_by_origin[origin_year] = int(train_years[-1])

        X_test = test[feature_cols].to_numpy(dtype=float)
        years_test = test["year"].to_numpy(dtype=int)

        for variant in ["normal", "t"]:
            df_draws = simulate_forecast_draws(rng, fit, X_test, years_test, variant=variant, n_draws=n_draws, y_floor=0.0)
            df_draws["origin_year"] = origin_year
            df_draws["h"] = df_draws["target_year"].astype(int) - origin_year
            rows_draws.append(df_draws)

    draws = pd.concat(rows_draws, ignore_index=True)
    draws = draws[["variant", "origin_year", "h", "target_year", "draw_id", "births_draw"]]

    # cases q10/q50/q90
    cases = summarize_draws_to_cases(draws, y_true_by_year=y_by_year, last_train_year_by_origin=last_train_year_by_origin)

    draws.to_csv(os.path.join(outdir, "backtest_draws_long_raw.csv.gz"), index=False, compression="gzip")
    cases.to_csv(os.path.join(outdir, "backtest_cases_raw.csv"), index=False)

    return draws, cases, y_by_year


def make_pit_plot(pits: pd.DataFrame, outpath: str) -> None:
    variants = sorted(pits["variant"].unique().tolist())
    hs = sorted(pits["h"].unique().tolist())
    nrows = len(variants)
    ncols = len(hs)
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(3.8*ncols, 2.8*nrows), squeeze=False)
    for i, v in enumerate(variants):
        for j, h in enumerate(hs):
            ax = axes[i, j]
            u = pits[(pits["variant"] == v) & (pits["h"] == h)]["pit"].to_numpy()
            ax.hist(u, bins=8, range=(0, 1))
            ax.set_title(f"PIT {v} h={h} (n={u.size})")
            ax.set_xlim(0, 1)
    plt.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def forecast_2025_2029(annual: pd.DataFrame, feature_cols: List[str], params: SSMParams,
                       lasso_lambda: float, n_draws: int, seed: int, outdir: str,
                       start_year: int = 2025, end_year: int = 2029):
    rng = np.random.default_rng(seed + 123)

    annual_obs = annual.dropna(subset=["births_total"]).sort_values("year").reset_index(drop=True)
    last_year = int(annual_obs["year"].iloc[-1])

    years_future = np.arange(start_year, end_year + 1, dtype=int)
    X_future = build_future_features(annual_obs, feature_cols, years_future)

    y_train = annual_obs["births_total"].to_numpy(dtype=float)
    X_train = annual_obs[feature_cols].to_numpy(dtype=float)
    fit = fit_em_lasso(y_train, X_train, params, lasso_lambda=lasso_lambda)

    all_rows = []
    for variant in ["normal", "t"]:
        df = simulate_forecast_draws(rng, fit, X_future, years_future, variant=variant, n_draws=n_draws, y_floor=0.0)
        all_rows.append(df)
    fdraws = pd.concat(all_rows, ignore_index=True)

    fdraws.to_csv(os.path.join(outdir, "forecast_draws_long_raw.csv.gz"), index=False, compression="gzip")
    return fdraws, last_year


def compute_fan_quantiles(draws: pd.DataFrame, val_col: str, out_csv: str) -> pd.DataFrame:
    g = draws.groupby(["variant", "target_year"], sort=False)[val_col]
    qs = g.quantile([0.1, 0.5, 0.9]).unstack(level=-1).reset_index()
    qs.columns = ["variant", "target_year", "q10", "q50", "q90"]
    qs.to_csv(out_csv, index=False)
    return qs


def plot_fan(history: pd.DataFrame, fan_q: pd.DataFrame, outpath: str, title: str, y_col: str = "births_total"):
    fig = plt.figure(figsize=(11.5, 5.5))
    ax = plt.gca()

    ax.plot(history["year"], history[y_col], label="history (births total)")

    for variant in sorted(fan_q["variant"].unique()):
        g = fan_q[fan_q["variant"] == variant].sort_values("target_year")
        x = g["target_year"].astype(int).to_numpy()
        q50 = g["q50"].astype(float).to_numpy()
        q10 = g["q10"].astype(float).to_numpy()
        q90 = g["q90"].astype(float).to_numpy()
        ax.plot(x, q50, label=f"{variant}: median")
        ax.fill_between(x, q10, q90, alpha=0.18, label=f"{variant}: 80% band")

    ax.set_title(title)
    ax.set_xlabel("Year")
    ax.set_ylabel("Live births (total)")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(outpath, dpi=150)
    plt.close(fig)


def anchor_params_from_pre2020(annual: pd.DataFrame, pre_end: int = 2019,
                               sig_level_frac: float = 0.06, sig_slope_frac: float = 0.02,
                               phi: float = 0.60) -> SSMParams:
    """
    Anchor scales from pre-2020 only. We keep it deliberately simple & stable.
    """
    df = annual.dropna(subset=["births_total"]).copy()
    df = df[df["year"].astype(int) <= int(pre_end)].sort_values("year")
    y = df["births_total"].to_numpy(dtype=float)
    t = np.arange(y.size, dtype=float)
    # detrend (linear)
    A = np.vstack([np.ones_like(t), t]).T
    coef = np.linalg.lstsq(A, y, rcond=None)[0]
    resid = y - A @ coef
    sig_y = float(np.std(resid, ddof=1))
    # set process noise as small fractions of measurement
    sig_level = float(sig_level_frac * sig_y)
    sig_slope = float(sig_slope_frac * sig_y)
    return SSMParams(sig_y=sig_y, sig_level=sig_level, sig_slope=sig_slope, phi=float(phi))


# ----------------------------
# Main
# ----------------------------

def build_arg_parser():
    p = argparse.ArgumentParser()
    p.add_argument("--annual", type=str, default="fertility_annual_v3.csv")
    p.add_argument("--outdir", type=str, default="outputs_v3_8")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--rolling_window", type=int, default=12)
    p.add_argument("--H", type=int, default=5)
    p.add_argument("--n_backtest_draws", type=int, default=1500)
    p.add_argument("--n_forecast_draws", type=int, default=4000)
    p.add_argument("--lasso_lambda", type=float, default=12.0)
    p.add_argument("--target_cov", type=float, default=0.80)
    p.add_argument("--pre_anchor_end", type=int, default=2019)
    p.add_argument("--phi", type=float, default=0.60)
    p.add_argument("--sig_level_frac", type=float, default=0.06)
    p.add_argument("--sig_slope_frac", type=float, default=0.02)
    p.add_argument("--pit_shrink_k", type=float, default=20.0)
    p.add_argument("--cal_shrink_k", type=float, default=20.0)
    return p


def main(argv: Optional[List[str]] = None):
    parser = build_arg_parser()
    # IMPORTANT: tolerate notebook-injected args (e.g. --f=...).
    if argv is None:
        args, unknown = parser.parse_known_args()
    else:
        args, unknown = parser.parse_known_args(argv)

    if unknown:
        print("[INFO] Ignoring unknown CLI args:", unknown)

    _ensure_dir(args.outdir)

    # load annual (support relative path)
    annual_path = args.annual
    if not os.path.exists(annual_path):
        # try alongside script location
        here = os.path.dirname(os.path.abspath(__file__))
        alt = os.path.join(here, annual_path)
        if os.path.exists(alt):
            annual_path = alt

    annual = pd.read_csv(annual_path)
    if "year" not in annual.columns or "births_total" not in annual.columns:
        raise ValueError("annual CSV must contain columns: year, births_total")
    # Keep only observed history (births_total not NaN). The CSV may already include placeholder future years.
    annual_obs = annual.dropna(subset=["births_total"]).copy()
    annual_obs["year"] = annual_obs["year"].astype(int)
    annual_obs = annual_obs.sort_values("year").reset_index(drop=True)

    # feature set (parsimonious)
    feature_cols = [
        "net_migration_total_signed",
        "log_ua_women15_49_stock_proxy",
        "war_decay",
        "hpi_yoy_log",
        "disp_income_yoy_log",
        "edu_share_tertiary",
    ]
    feature_cols = [c for c in feature_cols if c in annual.columns]

    # fill missing features with 0 (safe default for z-scored model)
    for c in feature_cols:
        annual_obs[c] = pd.to_numeric(annual_obs[c], errors="coerce")
    annual_obs[feature_cols] = annual_obs[feature_cols].fillna(method="ffill").fillna(0.0)

    # anchor params from pre-2020
    params = anchor_params_from_pre2020(
        annual_obs,
        pre_end=args.pre_anchor_end,
        sig_level_frac=args.sig_level_frac,
        sig_slope_frac=args.sig_slope_frac,
        phi=args.phi,
    )
    pd.DataFrame([params.__dict__]).to_csv(os.path.join(args.outdir, "anchored_ssm_params.csv"), index=False)

    # --- rolling backtest ---
    print("[INFO] Running rolling backtest (saving draws)...")
    draws_bt, cases_bt, y_by_year = run_rolling_backtest(
        annual=annual_obs,
        feature_cols=feature_cols,
        params=params,
        window=args.rolling_window,
        H=args.H,
        n_draws=args.n_backtest_draws,
        lasso_lambda=args.lasso_lambda,
        seed=args.seed,
        outdir=args.outdir,
    )

    # --- bias + width scaling by horizon (CAN shrink) ---
    bias_scale = fit_bias_scale_by_horizon(
        cases_bt,
        target_cov=args.target_cov,
        shrink_k=args.cal_shrink_k,
    )
    bias_scale.to_csv(os.path.join(args.outdir, "bias_scale_by_horizon.csv"), index=False)

    # apply to backtest draws and recompute cases
    bt_cal = apply_bias_scale_to_draws(draws_bt, bias_scale)
    bt_cal.to_csv(os.path.join(args.outdir, "backtest_draws_long_calibrated.csv.gz"), index=False, compression="gzip")

    cases_cal = summarize_draws_to_cases(
        bt_cal.rename(columns={"births_draw_cal": "births_draw"})[
            ["variant", "origin_year", "h", "target_year", "draw_id", "births_draw"]
        ],
        y_true_by_year=y_by_year,
        last_train_year_by_origin={int(k): int(k) for k in cases_bt["origin_year"].unique()},
    )
    cases_cal.to_csv(os.path.join(args.outdir, "backtest_cases_calibrated.csv"), index=False)

    # --- PIT by horizon from CALIBRATED draws (rolling) ---
    pits = compute_pit_values(bt_cal, y_true_by_year=y_by_year)
    pits.to_csv(os.path.join(args.outdir, "pit_values_by_case.csv"), index=False)

    beta_params = fit_beta_pit_by_horizon(pits, shrink_k=args.pit_shrink_k)
    beta_params.to_csv(os.path.join(args.outdir, "pit_beta_params_by_horizon.csv"), index=False)

    make_pit_plot(pits, os.path.join(args.outdir, "pit_hist_by_h.png"))

    # --- Forecast 2025-2029 ---
    print("[INFO] Forecasting 2025–2029 (saving draws)...")
    fdraws_raw, last_year = forecast_2025_2029(
        annual=annual_obs,
        feature_cols=feature_cols,
        params=params,
        lasso_lambda=args.lasso_lambda,
        n_draws=args.n_forecast_draws,
        seed=args.seed,
        outdir=args.outdir,
        start_year=2025,
        end_year=2029,
    )

    # attach horizon for calibration
    fdraws_raw["h"] = fdraws_raw["target_year"].astype(int) - int(last_year)

    # bias+scale calibration
    fdraws_cal = apply_bias_scale_to_draws(
        fdraws_raw.assign(origin_year=int(last_year), h=fdraws_raw["h"]),
        bias_scale,
    )
    fdraws_cal.to_csv(os.path.join(args.outdir, "forecast_draws_long_calibrated.csv.gz"), index=False, compression="gzip")

    # PIT calibration by horizon (Beta)
    fdraws_pit = apply_pit_beta_to_forecast_draws(
        forecast_draws_cal=fdraws_cal,
        beta_params=beta_params,
        last_hist_year=int(last_year),
    )
    fdraws_pit.to_csv(os.path.join(args.outdir, "forecast_draws_long_pitcal.csv.gz"), index=False, compression="gzip")

    # quantiles + plots
    q_raw = compute_fan_quantiles(fdraws_raw, "births_draw", os.path.join(args.outdir, "fan_quantiles_raw.csv"))
    q_cal = compute_fan_quantiles(fdraws_cal, "births_draw_cal", os.path.join(args.outdir, "fan_quantiles_calibrated.csv"))
    q_pit = compute_fan_quantiles(fdraws_pit, "births_draw_pitcal", os.path.join(args.outdir, "fan_quantiles_pitcal.csv"))

    plot_fan(annual_obs, q_raw, os.path.join(args.outdir, "fan_raw.png"),
             "Births forecast (2025–2029) – medians + raw 80% band (10–90)")
    plot_fan(annual_obs, q_cal, os.path.join(args.outdir, "fan_calibrated.png"),
             f"Births forecast (2025–2029) – medians + calibrated 80% band (target {args.target_cov:.2f})")
    plot_fan(annual_obs, q_pit, os.path.join(args.outdir, "fan_pitcal.png"),
             "Births forecast (2025–2029) – calibrated + PIT(Beta) by horizon")

    print("[INFO] Done. See:", args.outdir)


if __name__ == "__main__":
    main()
# %%
