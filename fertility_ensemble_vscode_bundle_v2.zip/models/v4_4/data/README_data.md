Copy your input CSVs here (see README.md).
