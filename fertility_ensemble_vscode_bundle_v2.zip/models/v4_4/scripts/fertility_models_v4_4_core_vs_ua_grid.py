#!/usr/bin/env python3
# -*- coding: utf-8 -*-

r"""
Fertility forecasting (CZ births, annual) — two comparable parsimonious models
============================================================================

Goal (assignment):
- Produce *practically implementable* 5-year-ahead forecasts of yearly live births in CZ.
- “Think structurally”: decompose the problem into a trend + a small set of drivers.
- Provide point forecast + decision-oriented quantile (planning) + predictive intervals.
- Use rolling backtests (h=1..5) + calibration diagnostics (coverage/PIT/pinball/bias-by-h).

------------------------------------------------------------
1) Observation target
------------------------------------------------------------
Let y_t be the log of total live births in year t:

    y_t = log(B_t)

We model y_t via:
- latent *local level* ℓ_t (slow-moving baseline),
- latent *damped slope* b_t (trend growth that mean-reverts via φ),
- a small set of covariates x_t (core vs UA model),
- and a targeted intervention for 2020–2022 (structural break / shock period).

------------------------------------------------------------
2) State-space structure (core for both variants)
------------------------------------------------------------
State vector: s_t = [ℓ_t, b_t]^T.

Transition (local linear trend with damping φ):
    ℓ_t = ℓ_{t-1} + b_{t-1} + η_t
    b_t = φ * b_{t-1} + ζ_t
where η_t ~ N(0, σ_ℓ^2), ζ_t ~ N(0, σ_b^2), φ in (0,1].

Observation:
    y_t = ℓ_t + x_t^T β + ε_t
    ε_t ~ N(0, σ_y^2 * m_t)

m_t is an optional variance multiplier for “shock years” (default: 2020–2022):
    m_t = shock_var_mult  if t in shock_years
    m_t = 1              otherwise

Intervention dummy (optional, default ON):
    x_t includes D_t = 1{t in 2020–2022} with coefficient β_D.

Anchoring process variance (optional, default ON):
- σ_ℓ^2 and σ_b^2 are estimated using innovations only up to anchor_year (default 2019),
  so that pandemic/war shock years do NOT inflate the long-run trend volatility.

------------------------------------------------------------
3) Two model variants (parsimonious comparison)
------------------------------------------------------------
CORE model covariates (examples; keep it small):
- Intercept
- war_step, war_decay (proxy for “geopolitical shock regime” after 2022)
- macro controls in yoy logs (e.g., disp_income_yoy_log, hpi_index_yoy_log)
- intervention dummy D_2020_2022 (recommended)

UA/MIGRATION model:
- all CORE covariates
- plus a proxy for temporary protection / UA stock:
    log_ua_women15_49_stock_proxy

You can compare CORE vs UA using the SAME rolling backtest and diagnostics.

------------------------------------------------------------
4) Estimation & prediction (conceptual steps)
------------------------------------------------------------
(1) Prepare data:
    - build y_t = log(births_total)
    - assemble x_t for both variants (standardize non-intercept columns)
    - define shock_years mask and anchor_year

(2) Fit each model on a training window using a Gibbs-style loop:
    - sample states s_{1:T} via FFBS (Kalman filter + backward sampling)
    - update β via LASSO-like coordinate descent on (y - ℓ) ~ Xβ (intercept unpenalized)
    - update σ_y^2 via inverse-gamma using scaled residuals (accounting for m_t)
    - update σ_ℓ^2, σ_b^2 via inverse-gamma using innovations (anchored pre-2020)

(3) Forecast:
    - draw from posterior samples and simulate s_{T+1:T+h} forward
    - simulate y_{T+h} and transform back: B = exp(y)

(4) Decision output:
    - planning quantile q* for asymmetric loss (under=5, over=1): q* = 5/(5+1)=0.833

(5) Validate (rolling backtest):
    - rolling window (length W), origins = {t0,...}, horizons h=1..5
    - save draws per case, quantiles, PIT, coverage, pinball, width, bias-by-h

------------------------------------------------------------
Usage
------------------------------------------------------------
PowerShell (use backtick ` for line continuation):

python ./scripts/fertility_models_v4_core_vs_ua.py `
  --annual ./data/fertility_annual_v3.csv `
  --panel  ./data/fertility_panel_v3.csv `
  --outdir ./outputs/v4 `
  --window 12 --hmax 5 `
  --phi 0.90 `
  --shock_years 2020,2021,2022 `
  --shock_var_mult 4.0 `
  --anchor_year 2019 `
  --n_iter 500 --burn 250 --thin 5 `
  --lasso_lambda 0.15 `
  --n_draws_per_case 400

VSCode (#%%):
- run the last cell at the bottom (it sets sys.argv and calls main()).

"""

from __future__ import annotations

import argparse
import math
import os
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# -----------------------------
# Utilities
# -----------------------------

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def _safe_read_csv(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Soubor nenalezen: {path}")
    return pd.read_csv(path, compression="infer")

def soft_threshold(z: float, lam: float) -> float:
    if z > lam:
        return z - lam
    if z < -lam:
        return z + lam
    return 0.0

def standardize_matrix(X: np.ndarray, penalize_mask: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Standardize columns that are penalized. Intercept (or any non-penalized) columns are unchanged.
    Returns (X_std, mean, std) where mean/std are for ALL columns (non-penalized have mean=0,std=1).
    """
    mean = np.zeros(X.shape[1], dtype=float)
    std = np.ones(X.shape[1], dtype=float)
    Xs = X.copy().astype(float)
    for j in range(X.shape[1]):
        if penalize_mask[j]:
            m = float(np.mean(Xs[:, j]))
            s = float(np.std(Xs[:, j]))
            if s < 1e-12:
                s = 1.0
            mean[j] = m
            std[j] = s
            Xs[:, j] = (Xs[:, j] - m) / s
    return Xs, mean, std

def lasso_coordinate_descent(
    X: np.ndarray,
    y: np.ndarray,
    lam: float,
    penalize_mask: np.ndarray,
    n_pass: int = 200,
    tol: float = 1e-6,
) -> np.ndarray:
    """
    Solve: 0.5*||y - Xb||^2 + lam*sum_{j penalized} |b_j|
    using coordinate descent. Non-penalized coords are updated with OLS step.
    """
    n, p = X.shape
    b = np.zeros(p, dtype=float)
    # Precompute column norms
    col_norm2 = np.sum(X * X, axis=0) + 1e-12

    r = y.copy()  # residual when b=0
    for _ in range(n_pass):
        b_old = b.copy()
        for j in range(p):
            # add back current effect
            r = r + X[:, j] * b[j]
            rho = float(np.dot(X[:, j], r))
            if penalize_mask[j]:
                b[j] = soft_threshold(rho, lam) / col_norm2[j]
            else:
                b[j] = rho / col_norm2[j]
            # remove updated effect
            r = r - X[:, j] * b[j]
        if np.max(np.abs(b - b_old)) < tol:
            break
    return b

def inv_gamma_sample(rng: np.random.Generator, shape: float, scale: float) -> float:
    """
    Sample from Inverse-Gamma(shape, scale), where density ∝ x^{-shape-1} exp(-scale/x).
    If G ~ Gamma(shape, rate=1/scale) => 1/G ~ InvGamma(shape, scale).
    numpy uses Gamma(k, theta=scale) (theta is *scale*). We want rate=1/scale -> theta=scale.
    Actually: if G ~ Gamma(shape, theta=1/scale) then 1/G ~ InvGamma(shape, scale).
    We'll implement with theta = 1/scale.
    """
    scale = max(scale, 1e-12)
    g = rng.gamma(shape, 1.0 / scale)
    return float(1.0 / max(g, 1e-18))

def symmetrize_and_jitter(P: np.ndarray, jitter: float = 1e-9) -> np.ndarray:
    P = 0.5 * (P + P.T)
    # ensure PSD (small jitter)
    return P + np.eye(P.shape[0]) * jitter


# -----------------------------
# State-space: FFBS for damped LLT
# -----------------------------

def ffbs_llt_damped(
    rng: np.random.Generator,
    y: np.ndarray,
    X: np.ndarray,
    beta: np.ndarray,
    sig_y2: float,
    sig_l2: float,
    sig_b2: float,
    phi: float,
    shock_mask: Optional[np.ndarray] = None,
    shock_var_mult: float = 1.0,
    m0: Optional[np.ndarray] = None,
    P0: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Forward-filter backward-sample for:
        s_t = F s_{t-1} + w_t, w_t ~ N(0,Q)
        y_t = H s_t + X_t beta + e_t, e_t ~ N(0, R_t)
    where s_t=[level,slope], H=[1,0].
    """
    T = len(y)
    F = np.array([[1.0, 1.0], [0.0, float(phi)]], dtype=float)
    H = np.array([[1.0, 0.0]], dtype=float)
    Q = np.array([[float(sig_l2), 0.0], [0.0, float(sig_b2)]], dtype=float)

    if m0 is None:
        m0 = np.array([float(y[0]), 0.0], dtype=float)
    if P0 is None:
        P0 = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=float) * 10.0

    shock_mask = np.zeros(T, dtype=bool) if shock_mask is None else shock_mask.astype(bool)

    # ---- helper: robust MVN sampler (prevents numerical failures) ----
    def _safe_mvn(rng: np.random.Generator, mean: np.ndarray, cov: np.ndarray) -> np.ndarray:
        """Sample N(mean, cov) with adaptive jitter.

        The model is intentionally lightweight; with small T and some extreme
        hyperparameter draws, the Kalman covariances can become slightly
        indefinite due to floating point roundoff. This helper keeps the code
        stable without changing the conceptual model.
        """
        cov = np.asarray(cov, dtype=float)
        cov = 0.5 * (cov + cov.T)
        if not np.all(np.isfinite(cov)):
            # fallback to safe diagonal if cov has NaN/inf
            d = np.nan_to_num(np.diag(cov), nan=1.0, posinf=1.0, neginf=1.0)
            d = np.clip(d, 1e-9, 1e12)
            cov = np.diag(d)

        mean = np.asarray(mean, dtype=float).reshape(-1)
        k = mean.shape[0]
        jitter = 1e-9
        I = np.eye(k)
        for _ in range(10):
            try:
                L = np.linalg.cholesky(cov + jitter * I)
                z = rng.standard_normal(k)
                return mean + L @ z
            except np.linalg.LinAlgError:
                jitter *= 10.0

        # last resort: sample only from the diagonal
        d = np.clip(np.diag(cov), 1e-9, 1e12)
        return mean + rng.standard_normal(k) * np.sqrt(d)

    # forward pass storage
    a = np.zeros((T, 2), dtype=float)     # predicted mean
    R = np.zeros((T, 2, 2), dtype=float)  # predicted cov
    m = np.zeros((T, 2), dtype=float)     # filtered mean
    C = np.zeros((T, 2, 2), dtype=float)  # filtered cov

    mt = m0.copy()
    Pt = P0.copy()

    for t in range(T):
        if t == 0:
            at = mt
            Rt = Pt
        else:
            at = F @ mt
            Rt = F @ Pt @ F.T + Q
        Rt = symmetrize_and_jitter(Rt, 1e-9)

        # observation
        y_tilde = y[t] - float(np.dot(X[t], beta))
        Rt_y = float(sig_y2 * (shock_var_mult if shock_mask[t] else 1.0))
        # H@Rt@H.T yields a (1,1) array; use .item() to safely get scalar
        S = float((H @ Rt @ H.T).item() + Rt_y)
        K = (Rt @ H.T) / max(S, 1e-18)  # (2,1)
        e = y_tilde - float((H @ at).item())

        # update (Joseph form keeps covariance PSD)
        mt = at + (K.flatten() * e)
        I2 = np.eye(2)
        KH = K @ H  # (2,1)@(1,2)->(2,2)
        Pt = (I2 - KH) @ Rt @ (I2 - KH).T + (K @ K.T) * Rt_y
        Pt = symmetrize_and_jitter(Pt, 1e-9)

        a[t] = at
        R[t] = Rt
        m[t] = mt
        C[t] = Pt

    # backward sampling
    states = np.zeros((T, 2), dtype=float)
    # sample s_T ~ N(m_T, C_T)
    CT = symmetrize_and_jitter(C[-1], 1e-8)
    states[-1] = _safe_mvn(rng, m[-1], CT)

    for t in range(T - 2, -1, -1):
        Rt1 = R[t + 1]
        Ct = C[t]
        # J = C_t F' R_{t+1}^{-1}
        Rt1i = np.linalg.inv(symmetrize_and_jitter(Rt1, 1e-9))
        J = Ct @ F.T @ Rt1i
        mean = m[t] + J @ (states[t + 1] - a[t + 1])
        cov = Ct - J @ Rt1 @ J.T
        cov = symmetrize_and_jitter(cov, 1e-8)
        states[t] = _safe_mvn(rng, mean, cov)

    return states


# -----------------------------
# Configuration
# -----------------------------

@dataclass
class ModelCfg:
    name: str
    covariates: List[str]
    use_intervention_dummy: bool = False
    shock_years: Tuple[int, ...] = (2020, 2021, 2022)
    shock_var_mult: float = 4.0
    # intervention variants (parsimonious toggles)
    use_variance_shock: bool = True               # variance inflation in shock_years
    use_post_level_shift: bool = False            # step dummy from post_shift_year onward
    post_shift_year: int = 2022                   # year from which the step dummy turns on
    anchor_year: int = 2019
    phi: float = 0.90
    lasso_lambda: float = 0.15
    n_iter: int = 500
    burn: int = 250
    thin: int = 5
    # variance priors (weakly informative on log-scale residuals)
    a_y: float = 2.0
    b_y: float = 0.002
    a_l: float = 2.0
    b_l: float = 0.01
    a_b: float = 2.0
    b_b: float = 0.01
    # safety clamps
    sig_floor: float = 1e-6
    sig_ceil: float = 1.0


# -----------------------------
# Data preparation
# -----------------------------

def build_design_matrix(
    df: pd.DataFrame,
    years: np.ndarray,
    covariates: list[str],
    shock_years: list[int],
    use_intervention_dummy: bool,
    use_variance_shock: bool,
    use_post_level_shift: bool,
    post_shift_year: int,
):
    """
    Build X matrix for y_t = level_t + beta'x_t + eps_t, with optional intervention dummies.

    Key design principles (parsimony + reproducibility):
      - Always include intercept.
      - Use only covariates that are available in df (missing -> ffill -> 0).
      - Ensure X has exactly len(years) rows (robust to missing years and duplicates).
      - Intervention options:
          * Temporary level dummy D_2020_2022 (only if use_intervention_dummy=True).
          * Post-shift step dummy D_postYYYY (only if use_post_level_shift=True).
          * Variance shock mask for observation noise (only if use_variance_shock=True).
    """
    years = np.asarray(years, dtype=int)
    if "year" not in df.columns:
        raise ValueError("df must contain column 'year'")

    # Ensure one row per year (keep last if duplicates exist)
    d0 = df.sort_values("year").drop_duplicates("year", keep="last").copy()
    d0["year"] = pd.to_numeric(d0["year"], errors="coerce").astype("Int64")
    d0 = d0.dropna(subset=["year"])
    d0["year"] = d0["year"].astype(int)

    # Build an index that includes history up to requested years, so ffill works for future scenarios
    y_min = int(min(d0["year"].min(), years.min()))
    y_max = int(max(d0["year"].max(), years.max()))
    full_years = np.arange(y_min, y_max + 1, dtype=int)

    d = d0.set_index("year").reindex(full_years)
    # forward-fill to extend last known covariates into future years (scenario = "hold last value")
    d = d.ffill().fillna(0.0)
    d = d.reindex(years).reset_index().rename(columns={"index": "year"})

    # Columns
    cols = ["intercept"] + list(covariates)
    if use_intervention_dummy:
        cols.append("D_2020_2022")
    if use_post_level_shift:
        cols.append(f"D_post{int(post_shift_year)}")

    X = np.ones((len(years), len(cols)), dtype=float)

    # Fill covariates + dummies
    for j, c in enumerate(cols[1:], start=1):
        if c == "D_2020_2022":
            X[:, j] = np.isin(years, np.asarray(shock_years, dtype=int)).astype(float)
            continue
        if c.startswith("D_post"):
            X[:, j] = (years >= int(post_shift_year)).astype(float)
            continue

        if c not in d.columns:
            # Missing covariate -> 0 (parsimonious default)
            X[:, j] = 0.0
            continue

        s = pd.to_numeric(d[c], errors="coerce").replace([np.inf, -np.inf], np.nan).astype(float)
        s = s.ffill().fillna(0.0)
        X[:, j] = s.to_numpy(dtype=float)

    # Penalize all except intercept (keep dummies penalized too for parsimony)
    penalize_mask = np.ones(len(cols), dtype=bool)
    penalize_mask[0] = False

    shock_mask = np.isin(years, np.asarray(shock_years, dtype=int)) if use_variance_shock else np.zeros(len(years), dtype=bool)
    return X, cols, penalize_mask, shock_mask



def extend_covariates_to_future(
    df_annual: pd.DataFrame,
    years_future: np.ndarray,
    covariates_needed: List[str],
) -> pd.DataFrame:
    """
    Create a minimal future covariate frame.
    Conservative defaults:
    - yoy macro logs -> 0
    - stock proxies -> last observed value
    - war_step -> 1 if >= first year war_step==1 in history, else 0
    - war_decay -> extend exponential decay fitted from last observed 3 points (if available), else hold last
    """
    df = df_annual.copy()
    last_year = int(df.loc[df["births_total"].notna(), "year"].max()) if "births_total" in df.columns else int(df["year"].max())
    last_row = df[df["year"] == last_year].iloc[0].to_dict()

    # war_step: detect start
    war_start_year = None
    if "war_step" in df.columns:
        ones = df[df["war_step"] >= 0.5]["year"]
        if len(ones) > 0:
            war_start_year = int(ones.min())

    # fit decay rate for war_decay
    decay_rate = None
    if "war_decay" in df.columns:
        sub = df[df["war_decay"] > 0].tail(3)
        if len(sub) >= 2:
            yv = sub["war_decay"].to_numpy()
            tv = sub["year"].to_numpy()
            # fit log-linear: log(decay)=a - k*(t - t0)
            # slope = -k
            lv = np.log(np.clip(yv, 1e-12, None))
            slope = np.polyfit(tv, lv, 1)[0]
            decay_rate = -float(slope)

    rows = []
    for y in years_future:
        r = {"year": int(y)}
        for c in covariates_needed:
            if c in df.columns:
                if c.endswith("_yoy_log"):
                    r[c] = 0.0
                elif c.startswith("log_ua_") or c.endswith("_stock_proxy") or c.startswith("log_"):
                    # stock / log levels: hold last
                    r[c] = float(last_row.get(c, 0.0))
                elif c == "war_step":
                    if war_start_year is None:
                        r[c] = float(last_row.get(c, 0.0))
                    else:
                        r[c] = 1.0 if int(y) >= war_start_year else 0.0
                elif c == "war_decay":
                    if decay_rate is None or war_start_year is None:
                        r[c] = float(last_row.get(c, 0.0))
                    else:
                        dt = int(y) - war_start_year
                        r[c] = float(math.exp(-decay_rate * max(dt, 0)))
                else:
                    # default: carry forward last value
                    r[c] = float(last_row.get(c, 0.0))
            else:
                # unknown covariate: 0
                r[c] = 0.0
        rows.append(r)

    return pd.DataFrame(rows)


# -----------------------------
# Model fitting and forecasting
# -----------------------------

def fit_posterior(
    rng: np.random.Generator,
    y: np.ndarray,
    X_raw: np.ndarray,
    years: np.ndarray,
    cfg: ModelCfg,
    penalize_mask: np.ndarray,
    shock_mask: np.ndarray,
) -> Dict[str, np.ndarray]:
    """
    Returns dict with arrays of posterior draws:
      beta_draws (S,p), sig_y2_draws (S,), sig_l2_draws, sig_b2_draws, level_T_draws, slope_T_draws
    """
    # Standardize penalized columns for stable lasso updates
    X, X_mean, X_std = standardize_matrix(X_raw, penalize_mask)

    # init
    beta = np.zeros(X.shape[1], dtype=float)
    sig_y2 = float(max(np.var(y) * 0.2, cfg.sig_floor))
    sig_l2 = float(max(1e-3, cfg.sig_floor))
    sig_b2 = float(max(1e-3, cfg.sig_floor))

    # storage
    keep_idx = [it for it in range(cfg.n_iter) if (it >= cfg.burn and ((it - cfg.burn) % cfg.thin == 0))]
    S = len(keep_idx)
    beta_draws = np.zeros((S, X.shape[1]), dtype=float)
    sig_y2_draws = np.zeros(S, dtype=float)
    sig_l2_draws = np.zeros(S, dtype=float)
    sig_b2_draws = np.zeros(S, dtype=float)
    levelT = np.zeros(S, dtype=float)
    slopeT = np.zeros(S, dtype=float)

    # indices for anchored innovations
    anchor_mask = years[1:] <= cfg.anchor_year  # for innovations t=2..T
    anchor_mask = anchor_mask.astype(bool)

    k = 0
    for it in range(cfg.n_iter):
        # 1) sample states
        states = ffbs_llt_damped(
            rng=rng,
            y=y,
            X=X,
            beta=beta,
            sig_y2=sig_y2,
            sig_l2=sig_l2,
            sig_b2=sig_b2,
            phi=cfg.phi,
            shock_mask=shock_mask,
            shock_var_mult=cfg.shock_var_mult,
        )
        level = states[:, 0]
        slope = states[:, 1]

        # 2) update beta via LASSO on residuals (y - level)
        y_star = y - level
        beta = lasso_coordinate_descent(
            X=X,
            y=y_star,
            lam=cfg.lasso_lambda,
            penalize_mask=penalize_mask,
            n_pass=200,
            tol=1e-6,
        )

        # 3) update observation variance sig_y2 using scaled residuals
        resid = y - level - (X @ beta)
        mult = np.where(shock_mask, cfg.shock_var_mult, 1.0)
        resid_scaled = resid / np.sqrt(mult)
        a_post = cfg.a_y + 0.5 * len(y)
        b_post = cfg.b_y + 0.5 * float(np.dot(resid_scaled, resid_scaled))
        sig_y2 = inv_gamma_sample(rng, a_post, b_post)
        sig_y2 = float(np.clip(sig_y2, cfg.sig_floor, cfg.sig_ceil))

        # 4) update process variances from innovations (anchored pre-2020)
        # innovations:
        eta = level[1:] - (level[:-1] + slope[:-1])
        zeta = slope[1:] - (cfg.phi * slope[:-1])

        eta_use = eta[anchor_mask] if np.any(anchor_mask) else eta
        zeta_use = zeta[anchor_mask] if np.any(anchor_mask) else zeta

        aL = cfg.a_l + 0.5 * len(eta_use)
        bL = cfg.b_l + 0.5 * float(np.dot(eta_use, eta_use))
        sig_l2 = inv_gamma_sample(rng, aL, bL)
        sig_l2 = float(np.clip(sig_l2, cfg.sig_floor, cfg.sig_ceil))

        aB = cfg.a_b + 0.5 * len(zeta_use)
        bB = cfg.b_b + 0.5 * float(np.dot(zeta_use, zeta_use))
        sig_b2 = inv_gamma_sample(rng, aB, bB)
        sig_b2 = float(np.clip(sig_b2, cfg.sig_floor, cfg.sig_ceil))

        if it in keep_idx:
            beta_draws[k] = beta
            sig_y2_draws[k] = sig_y2
            sig_l2_draws[k] = sig_l2
            sig_b2_draws[k] = sig_b2
            levelT[k] = float(level[-1])
            slopeT[k] = float(slope[-1])
            k += 1

    return {
        "beta_draws": beta_draws,
        "sig_y2": sig_y2_draws,
        "sig_l2": sig_l2_draws,
        "sig_b2": sig_b2_draws,
        "levelT": levelT,
        "slopeT": slopeT,
        "X_mean": X_mean,
        "X_std": X_std,
    }


def simulate_forecast_draws(
    rng: np.random.Generator,
    posterior: Dict[str, np.ndarray],
    X_future_raw: np.ndarray,
    years_future: np.ndarray,
    phi: float,
    shock_years: Tuple[int, ...],
    shock_var_mult: float,
    n_draws: int,
) -> np.ndarray:
    """
    Produce forecast draws for B_{t}=exp(y_t) for each future year.
    Returns array (n_draws, H).
    """
    beta_draws = posterior["beta_draws"]
    sig_y2 = posterior["sig_y2"]
    sig_l2 = posterior["sig_l2"]
    sig_b2 = posterior["sig_b2"]
    levelT = posterior["levelT"]
    slopeT = posterior["slopeT"]
    X_mean = posterior["X_mean"]
    X_std = posterior["X_std"]

    # standardize future X using training stats (penalized columns only)
    Xf = X_future_raw.copy().astype(float)
    for j in range(Xf.shape[1]):
        if abs(X_std[j] - 1.0) > 1e-12 or abs(X_mean[j]) > 1e-12:
            Xf[:, j] = (Xf[:, j] - X_mean[j]) / X_std[j]

    H = len(years_future)
    out = np.zeros((n_draws, H), dtype=float)

    # choose posterior indices with replacement
    S = beta_draws.shape[0]
    idx = rng.integers(0, S, size=n_draws)

    shock_set = set(shock_years)
    for i in range(n_draws):
        k = int(idx[i])
        beta = beta_draws[k]
        sy2 = float(sig_y2[k])
        sl2 = float(sig_l2[k])
        sb2 = float(sig_b2[k])

        level = float(levelT[k])
        slope = float(slopeT[k])

        for h in range(H):
            # state evolution
            eta = rng.normal(0.0, math.sqrt(max(sl2, 1e-18)))
            zeta = rng.normal(0.0, math.sqrt(max(sb2, 1e-18)))

            level_next = level + slope + eta
            slope_next = phi * slope + zeta

            # observation
            m = shock_var_mult if int(years_future[h]) in shock_set else 1.0
            eps = rng.normal(0.0, math.sqrt(max(sy2 * m, 1e-18)))
            yhat = level_next + float(np.dot(Xf[h], beta)) + eps

            out[i, h] = float(math.exp(yhat))

            level, slope = level_next, slope_next

    return out


# -----------------------------
# Backtest + diagnostics
# -----------------------------

def compute_pinball(y_true: np.ndarray, q: np.ndarray, tau: float) -> float:
    u = y_true - q
    return float(np.mean(np.maximum(tau * u, (tau - 1.0) * u)))

def pit_value(draws: np.ndarray, y_true: float) -> float:
    # randomized PIT (jitter) could be used; keep simple empirical CDF
    return float(np.mean(draws <= y_true))

def run_rolling_backtest(
    rng: np.random.Generator,
    df_annual: pd.DataFrame,
    cfgs: List[ModelCfg],
    outdir: str,
    window: int,
    hmax: int,
    n_draws_per_case: int,
    taus: List[float],
    band: float,
    last_origin_only: bool = False,
) -> None:
    ensure_dir(outdir)

    df = df_annual.copy()
    df = df.sort_values("year").reset_index(drop=True)
    # IMPORTANT: keep only years with observed births_total for backtest; otherwise y_true becomes NaN and diagnostics break
    if "births_total" in df.columns:
        df = df[df["births_total"].notna()].reset_index(drop=True)

    years_all = df["year"].astype(int).to_numpy()
    first_year, last_year = int(years_all.min()), int(years_all.max())

    # find target column
    if "births_total" in df.columns:
        B = df["births_total"].astype(float).to_numpy()
    else:
        raise ValueError("annual dataset musí obsahovat 'births_total'.")
    y_all = np.log(np.clip(B, 1e-12, None))

    # pick origins such that we have window and truth for max horizon
    origins = []
    for origin in years_all:
        if origin < first_year + window - 1:
            continue
        if origin + hmax > last_year:
            continue
        origins.append(int(origin))
    if len(origins) == 0:
        raise ValueError("Nenalezeny žádné origin years pro rolling backtest (zvyšte data nebo snižte window/hmax).")

    # stabilize + debug (helps when running in VSCode)
    origins = sorted(set(origins))
    if last_origin_only:
        origins = [origins[-1]]
    try:
        os.makedirs(outdir, exist_ok=True)
        pd.DataFrame({"origin_year": origins}).to_csv(os.path.join(outdir, "origins_used.csv"), index=False)
    except Exception:
        pass
    print(f"[backtest] window={window} hmax={hmax} years={first_year}-{last_year} origins={len(origins)} ({origins[0]}..{origins[-1]})")

    draws_rows = []
    cases_rows = []

    for cfg in cfgs:
        # build X over all years once (will subset per window)
        X_all, colnames, penalize_mask, shock_mask_all = build_design_matrix(
            df=df,
            years=years_all,
            covariates=cfg.covariates,
            shock_years=cfg.shock_years,
            use_intervention_dummy=cfg.use_intervention_dummy,
            use_variance_shock=cfg.use_variance_shock,
            use_post_level_shift=cfg.use_post_level_shift,
            post_shift_year=cfg.post_shift_year,
        )

        for origin in origins:
            train_years = np.arange(origin - window + 1, origin + 1, dtype=int)
            test_years = np.arange(origin + 1, origin + hmax + 1, dtype=int)

            # indices
            tr_idx = np.isin(years_all, train_years)
            te_idx = np.isin(years_all, test_years)

            y_tr = y_all[tr_idx]
            years_tr = years_all[tr_idx]
            X_tr = X_all[tr_idx]
            shock_tr = shock_mask_all[tr_idx]

            # fit posterior on training window
            post = fit_posterior(
                rng=rng,
                y=y_tr,
                X_raw=X_tr,
                years=years_tr,
                cfg=cfg,
                penalize_mask=penalize_mask,
                shock_mask=shock_tr,
            )

            # future covariates are taken from actual realized x_t in backtest (this is standard for conditional forecasts)
            X_te_raw = X_all[te_idx]
            years_te = years_all[te_idx]

            draws = simulate_forecast_draws(
                rng=rng,
                posterior=post,
                X_future_raw=X_te_raw,
                years_future=years_te,
                phi=cfg.phi,
                shock_years=cfg.shock_years,
                shock_var_mult=cfg.shock_var_mult,
                n_draws=n_draws_per_case,
            )
            if not np.isfinite(draws).all():
                bad = np.sum(~np.isfinite(draws))
                raise FloatingPointError(f"Forecast draws obsahují NaN/Inf (count={bad}). Zkontroluj covariáty a fit pouze na observed years.")

            # truth in levels
            B_true = B[te_idx]

            # per horizon case
            alpha = (1.0 - band) / 2.0
            q_lo = alpha
            q_hi = 1.0 - alpha
            q_plan = 5.0 / 6.0  # 5:1 under:over

            for j, target_year in enumerate(years_te):
                h = int(target_year - origin)
                d = draws[:, j]
                q10 = float(np.quantile(d, q_lo))
                q50 = float(np.quantile(d, 0.5))
                q90 = float(np.quantile(d, q_hi))
                qpl = float(np.quantile(d, q_plan))
                yt = float(B_true[j])
                pit = pit_value(d, yt)

                cases_rows.append({
                    "model": cfg.name,
                    "origin_year": origin,
                    "target_year": int(target_year),
                    "h": h,
                    "y_true": yt,
                    "q_lo": q10,
                    "q50": q50,
                    "q_hi": q90,
                    "q_plan": qpl,
                    "pit": pit,
                })

                # store long draws
                # (store all draws; may be large but horizons are small)
                for i in range(n_draws_per_case):
                    draws_rows.append({
                        "model": cfg.name,
                        "origin_year": origin,
                        "target_year": int(target_year),
                        "h": h,
                        "draw_id": i,
                        "births_draw": float(d[i]),
                        "y_true": yt,
                    })

                if int(target_year) == int(test_years[-1]):
                    print(f"[backtest] model={cfg.name:>12s} origin={origin} done.")

    # Save draws and cases
    draws_df = pd.DataFrame(draws_rows)
    # Backward/forward compatibility: ensure required keys exist
    if 'model' not in draws_df.columns:
        if 'variant' in draws_df.columns:
            draws_df['model'] = draws_df['variant']
        elif 'cfg' in draws_df.columns:
            draws_df['model'] = draws_df['cfg']
        elif 'name' in draws_df.columns:
            draws_df['model'] = draws_df['name']
        else:
            draws_df['model'] = 'model'
    if 'h' not in draws_df.columns:
        if 'target_year' in draws_df.columns and 'origin_year' in draws_df.columns:
            draws_df['h'] = pd.to_numeric(draws_df['target_year'], errors='coerce') - pd.to_numeric(draws_df['origin_year'], errors='coerce')
        elif 'target' in draws_df.columns and 'origin' in draws_df.columns:
            draws_df['h'] = pd.to_numeric(draws_df['target'], errors='coerce') - pd.to_numeric(draws_df['origin'], errors='coerce')
        elif 'target' in draws_df.columns and 'origin_year' in draws_df.columns:
            draws_df['h'] = pd.to_numeric(draws_df['target'], errors='coerce') - pd.to_numeric(draws_df['origin_year'], errors='coerce')
        elif 'target_year' in draws_df.columns and 'origin' in draws_df.columns:
            draws_df['h'] = pd.to_numeric(draws_df['target_year'], errors='coerce') - pd.to_numeric(draws_df['origin'], errors='coerce')
        else:
            # last-resort: try to parse from existing column names
            draws_df['h'] = np.nan
    draws_df['h'] = pd.to_numeric(draws_df['h'], errors='coerce')
    cases_df = pd.DataFrame(cases_rows)

    if len(cases_df) == 0:
        pd.DataFrame([], columns=["model","h","n","coverage","mean_width","bias_mean","rmse","pit_mean"]).to_csv(os.path.join(outdir, "backtest_metrics_by_h.csv"), index=False)
        pd.DataFrame([], columns=["model","h","tau","pinball"]).to_csv(os.path.join(outdir, "pinball_by_h.csv"), index=False)
        pd.DataFrame([], columns=["model","h","pit_mean","pit_std"]).to_csv(os.path.join(outdir, "pit_by_h.csv"), index=False)
        print("[WARN] Rolling backtest produced 0 cases. Check window/hmax and births_total coverage.")
        return
    # Backward/forward compatibility: ensure required keys exist
    if 'model' not in cases_df.columns:
        if 'variant' in cases_df.columns:
            cases_df['model'] = cases_df['variant']
        elif 'cfg' in cases_df.columns:
            cases_df['model'] = cases_df['cfg']
        elif 'name' in cases_df.columns:
            cases_df['model'] = cases_df['name']
        else:
            cases_df['model'] = 'model'
    if 'h' not in cases_df.columns:
        if 'target_year' in cases_df.columns and 'origin_year' in cases_df.columns:
            cases_df['h'] = pd.to_numeric(cases_df['target_year'], errors='coerce') - pd.to_numeric(cases_df['origin_year'], errors='coerce')
        elif 'target' in cases_df.columns and 'origin' in cases_df.columns:
            cases_df['h'] = pd.to_numeric(cases_df['target'], errors='coerce') - pd.to_numeric(cases_df['origin'], errors='coerce')
        elif 'target' in cases_df.columns and 'origin_year' in cases_df.columns:
            cases_df['h'] = pd.to_numeric(cases_df['target'], errors='coerce') - pd.to_numeric(cases_df['origin_year'], errors='coerce')
        elif 'target_year' in cases_df.columns and 'origin' in cases_df.columns:
            cases_df['h'] = pd.to_numeric(cases_df['target_year'], errors='coerce') - pd.to_numeric(cases_df['origin'], errors='coerce')
        else:
            # last-resort: try to parse from existing column names
            cases_df['h'] = np.nan
    cases_df['h'] = pd.to_numeric(cases_df['h'], errors='coerce')
    # defensive: drop cases without truth
    if "y_true" in cases_df.columns:
        cases_df = cases_df.dropna(subset=["y_true"]).reset_index(drop=True)

    draws_path = os.path.join(outdir, "backtest_draws_long.csv.gz")
    cases_path = os.path.join(outdir, "backtest_cases.csv")
    draws_df.to_csv(draws_path, index=False, compression="gzip")
    cases_df.to_csv(cases_path, index=False)
    # Convenience export: q10/q50/q90 per (origin,h) for reporting
    try:
        qcases = cases_df.copy()
        if "q_lo" in qcases.columns:
            qcases["q10"] = qcases["q_lo"]
        if "q_hi" in qcases.columns:
            qcases["q90"] = qcases["q_hi"]
        keep_cols = [c for c in ["model","origin_year","target_year","h","y_true","q10","q50","q90","q_plan","pit"] if c in qcases.columns]
        qcases[keep_cols].to_csv(os.path.join(outdir, "quantiles_by_case.csv"), index=False)
    except Exception:
        pass
    print("[saved]", draws_path)
    print("[saved]", cases_path)

    # Metrics by horizon
    metrics = []
    for (model, h), g in cases_df.groupby(["model", "h"]):
        y = g["y_true"].to_numpy()
        qlo = g["q_lo"].to_numpy()
        qhi = g["q_hi"].to_numpy()
        q50 = g["q50"].to_numpy()
        cov = float(np.mean((y >= qlo) & (y <= qhi)))
        width = float(np.mean(qhi - qlo))
        bias = float(np.mean(q50 - y))
        rmse = float(np.sqrt(np.mean((q50 - y) ** 2)))
        metrics.append({
            "model": model,
            "h": int(h),
            "n": int(len(g)),
            "coverage": cov,
            "mean_width": width,
            "bias_mean": bias,
            "rmse": rmse,
            "pit_mean": float(np.mean(g["pit"].to_numpy())),
        })
    metrics_df = pd.DataFrame(metrics).sort_values(["model", "h"])
    metrics_df.to_csv(os.path.join(outdir, "backtest_metrics_by_h.csv"), index=False)

    # Pinball by horizon
    pb_rows = []
    for (model, h), g in cases_df.groupby(["model", "h"]):
        y = g["y_true"].to_numpy()
        # we only have q at taus=0.1,0.5,0.9 if user requested; approximate by q_lo,q50,q_hi for 80% band
        q_map = {0.5: g["q50"].to_numpy()}
        # map lower/upper band to taus if matching common values
        # if band=0.80 => q_lo = 0.10, q_hi=0.90
        q_map[0.1] = g["q_lo"].to_numpy()
        q_map[0.9] = g["q_hi"].to_numpy()
        for tau in taus:
            if tau in q_map:
                qv = q_map[tau]
                pb = compute_pinball(y, qv, tau)
                pb_rows.append({"model": model, "h": int(h), "tau": float(tau), "pinball": pb})
        # asymmetric planning loss: cost_over : cost_under = 5 : 1  => optimal tau = 5/(5+1)
        if "q_plan" in g.columns:
            tau_plan = 5.0 / 6.0
            qv = g["q_plan"].to_numpy()
            if np.all(np.isfinite(qv)):
                pb = compute_pinball(y, qv, tau_plan)
                pb_rows.append({"model": model, "h": int(h), "tau": float(tau_plan), "pinball": pb, "tag": "plan_5to1"})
    pb_df = pd.DataFrame(pb_rows)
    if len(pb_df) > 0:
        pb_df = pb_df.sort_values(["model", "h", "tau"])
    pb_df.to_csv(os.path.join(outdir, "pinball_by_h.csv"), index=False)

    # PIT tables
    pit_by_case = cases_df[["model", "origin_year", "target_year", "h", "pit"]].copy()
    pit_by_case.to_csv(os.path.join(outdir, "pit_by_case.csv"), index=False)
    pit_by_h = pit_by_case.groupby(["model", "h"]).agg(
        n=("pit", "size"),
        pit_mean=("pit", "mean"),
        pit_std=("pit", "std"),
    ).reset_index().sort_values(["model", "h"])
    pit_by_h.to_csv(os.path.join(outdir, "pit_by_h.csv"), index=False)

    # PIT histograms by h
    hs = sorted(cases_df["h"].unique())
    models = sorted(cases_df["model"].unique())
    nrows = len(models)
    ncols = len(hs)
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(4*ncols, 3*nrows), squeeze=False)
    for i, model in enumerate(models):
        for j, h in enumerate(hs):
            ax = axes[i, j]
            pits = cases_df[(cases_df["model"] == model) & (cases_df["h"] == h)]["pit"].to_numpy()
            ax.hist(pits, bins=10, range=(0, 1))
            ax.set_title(f"PIT {model} h={h} (n={len(pits)})")
            ax.set_xlim(0, 1)
    plt.tight_layout()
    figpath = os.path.join(outdir, "pit_hist_by_h.png")
    plt.savefig(figpath, dpi=150)
    plt.close(fig)
    print("[saved]", figpath)


def fit_and_forecast_full_sample(
    rng: np.random.Generator,
    df_annual: pd.DataFrame,
    cfgs: List[ModelCfg],
    outdir: str,
    forecast_years: List[int],
    n_forecast_draws: int,
) -> None:
    ensure_dir(outdir)
    df = df_annual.copy().sort_values("year").reset_index(drop=True)

    years_all = df["year"].astype(int).to_numpy()
    if "births_total" not in df.columns:
        raise ValueError("annual dataset musí obsahovat 'births_total'.")
    B = df["births_total"].astype(float).to_numpy()
    obs_mask = np.isfinite(B)
    if obs_mask.sum() < 5:
        raise ValueError("Příliš málo pozorování births_total pro odhad (po odfiltrování NaN).")
    years_obs = years_all[obs_mask]
    y_obs = np.log(np.clip(B[obs_mask], 1e-12, None))
    last_obs_year = int(years_obs.max())

    # future covariate frame (minimal scenario)
    if any(int(y) <= last_obs_year for y in forecast_years):
        raise ValueError(f"forecast_years musí být > last_obs_year={last_obs_year}. Dostali jsme: {forecast_years}")

    cov_needed = sorted({c for cfg in cfgs for c in cfg.covariates})
    df_future = extend_covariates_to_future(df, np.array(forecast_years, dtype=int), cov_needed)

    rows_draws = []
    rows_quant = []

    for cfg in cfgs:
        X_all, colnames, penalize_mask, shock_mask = build_design_matrix(
            df=df,
            years=years_all,
            covariates=cfg.covariates,
            shock_years=cfg.shock_years,
            use_intervention_dummy=cfg.use_intervention_dummy,
            use_variance_shock=cfg.use_variance_shock,
            use_post_level_shift=cfg.use_post_level_shift,
            post_shift_year=cfg.post_shift_year,
        )

        # restrict to observed years for fitting (avoid NaNs in births_total future rows)
        X_obs = X_all[obs_mask, :]
        shock_mask_obs = shock_mask[obs_mask]

        post = fit_posterior(
            rng=rng,
            y=y_obs,
            X_raw=X_obs,
            years=years_obs,
            cfg=cfg,
            penalize_mask=penalize_mask,
            shock_mask=shock_mask_obs,
        )

        # build future X with same columns order
        df_for_X = pd.concat([df[["year"] + cfg.covariates].copy(), df_future[["year"] + cfg.covariates].copy()], ignore_index=True)
        # build in the same function by passing df_for_X and years_future (it expects year index)
        # easiest: create a temp DF containing needed columns and year
        temp = df_for_X.copy()
        # add D dummy will be constructed in builder
        X_future_raw, _, _, _ = build_design_matrix(
            df=temp,
            years=np.array(forecast_years, dtype=int),
            covariates=cfg.covariates,
            shock_years=cfg.shock_years,
            use_intervention_dummy=cfg.use_intervention_dummy,
            use_variance_shock=cfg.use_variance_shock,
            use_post_level_shift=cfg.use_post_level_shift,
            post_shift_year=cfg.post_shift_year,
        )

        draws = simulate_forecast_draws(
            rng=rng,
            posterior=post,
            X_future_raw=X_future_raw,
            years_future=np.array(forecast_years, dtype=int),
            phi=cfg.phi,
            shock_years=cfg.shock_years,
            shock_var_mult=cfg.shock_var_mult,
            n_draws=n_forecast_draws,
        )

        # save long draws
        for i in range(n_forecast_draws):
            for j, y in enumerate(forecast_years):
                rows_draws.append({
                    "model": cfg.name,
                    "target_year": int(y),
                    "h": int(y - int(last_obs_year)),
                    "draw_id": int(i),
                    "births_draw": float(draws[i, j]),
                })

        # quantiles (80% band and planning)
        alpha = 0.10
        q_plan = 5.0/6.0
        for j, y in enumerate(forecast_years):
            d = draws[:, j]
            rows_quant.append({
                "model": cfg.name,
                "target_year": int(y),
                "q10": float(np.quantile(d, alpha)),
                "q50": float(np.quantile(d, 0.5)),
                "q90": float(np.quantile(d, 1.0 - alpha)),
                "q_plan_5to1": float(np.quantile(d, q_plan)),
                "mean": float(np.mean(d)),
            })

        print(f"[forecast] model={cfg.name} done.")

    draws_df = pd.DataFrame(rows_draws)
    quant_df = pd.DataFrame(rows_quant)

    draws_df.to_csv(os.path.join(outdir, "forecast_draws_long.csv.gz"), index=False, compression="gzip")
    quant_df.to_csv(os.path.join(outdir, "forecast_quantiles.csv"), index=False)

    # simple fan chart plot (medians + 80% band)
    plt.figure(figsize=(10, 5))
    plt.plot(years_all, B, label="history (births_total)")
    for model in sorted(quant_df["model"].unique()):
        q = quant_df[quant_df["model"] == model].sort_values("target_year")
        # robust numeric casting (prevents matplotlib dtype issues)
        x = pd.to_numeric(q["target_year"], errors="coerce").to_numpy(dtype=float)
        q10 = pd.to_numeric(q["q10"], errors="coerce").to_numpy(dtype=float)
        q50 = pd.to_numeric(q["q50"], errors="coerce").to_numpy(dtype=float)
        q90 = pd.to_numeric(q["q90"], errors="coerce").to_numpy(dtype=float)
        plt.plot(x, q50, label=f"{model}: median")
        plt.fill_between(x, q10, q90, alpha=0.2, label=f"{model}: 80% band")
    plt.title(f"Births forecast ({forecast_years[0]}–{forecast_years[-1]}) – medians + 80% band")
    plt.xlabel("Year")
    plt.ylabel("Live births (total)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fan_chart_forecast.png"), dpi=150)
    plt.close()


# -----------------------------
# CLI
# -----------------------------

def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(add_help=True)
    p.add_argument("--annual", type=str, required=True, help="Path to fertility_annual_v3.csv")
    p.add_argument("--panel", type=str, required=False, default="", help="Optional: fertility_panel_v3.csv (not required for this v4 script)")
    p.add_argument("--outdir", type=str, required=True)
    p.add_argument("--seed", type=int, default=123)

    p.add_argument("--phi", type=float, default=0.90)
    p.add_argument("--shock_years", type=str, default="2020,2021,2022")
    p.add_argument("--shock_var_mult", type=float, default=4.0)
    p.add_argument("--anchor_year", type=int, default=2019)

    p.add_argument("--post_shift_year", type=int, default=2022)  # start of post-shift intervention

    p.add_argument("--window", type=int, default=12)
    p.add_argument("--hmax", type=int, default=5)
    p.add_argument("--n_iter", type=int, default=500)
    p.add_argument("--burn", type=int, default=250)
    p.add_argument("--thin", type=int, default=5)
    p.add_argument("--lasso_lambda", type=float, default=0.15)

    p.add_argument("--n_draws_per_case", type=int, default=400)
    p.add_argument("--n_forecast_draws", type=int, default=2000)
    p.add_argument("--skip_backtest", type=int, default=0)
    p.add_argument("--last_origin_only", type=int, default=0, help="If 1, run rolling backtest only for last origin (debug/quick).")

    # ignore unknown args (IPykernel passes --f=... etc.)
    if argv is None:
        argv = sys.argv[1:]
    args, unknown = p.parse_known_args(argv)
    # silently ignore unknown ipykernel args
    _ = unknown
    return args

def main(argv: Optional[List[str]] = None) -> None:
    args = parse_args(argv)
    ensure_dir(args.outdir)

    df_annual = _safe_read_csv(args.annual)
    if "year" not in df_annual.columns:
        raise ValueError("annual dataset musí obsahovat sloupec 'year'.")

    shock_years = tuple(int(x.strip()) for x in args.shock_years.split(",") if x.strip())
    rng = np.random.default_rng(int(args.seed))

    # Define two parsimonious models
    core_covs = [
        "war_step",
        "war_decay",
        "disp_income_yoy_log",
        "hpi_index_yoy_log",
    ]
    ua_covs = core_covs + ["log_ua_women15_49_stock_proxy"]

    cfg_core = ModelCfg(
        name="core",
        covariates=core_covs,
        use_intervention_dummy=True,
        shock_years=shock_years,
        shock_var_mult=float(args.shock_var_mult),
        anchor_year=int(args.anchor_year),
        phi=float(args.phi),
        lasso_lambda=float(args.lasso_lambda),
        n_iter=int(args.n_iter),
        burn=int(args.burn),
        thin=int(args.thin),
    )
    cfg_ua = ModelCfg(
        name="ua",
        covariates=ua_covs,
        use_intervention_dummy=True,
        shock_years=shock_years,
        shock_var_mult=float(args.shock_var_mult),
        anchor_year=int(args.anchor_year),
        phi=float(args.phi),
        lasso_lambda=float(args.lasso_lambda),
        n_iter=int(args.n_iter),
        burn=int(args.burn),
        thin=int(args.thin),
    )


    # --- Build 4-model grid: (core vs UA) × (variance-shock vs post-2022 level shift) ---
    # Intervention type A: variance shock only in 2020–2022 (observation variance inflation)
    # Intervention type B: post-2022 level shift (step dummy) – permanent mean shift from 2022 onward
    # For this comparison we keep the temporary mean dummy D_2020_2022 OFF (parsimonious).
    grid = [
        dict(tag="varshock", use_variance_shock=True,  use_post_level_shift=False),
        dict(tag="postshift", use_variance_shock=False, use_post_level_shift=True),
    ]

    cfgs = []
    for base in [cfg_core, cfg_ua]:
        for g in grid:
            c = ModelCfg(**{**base.__dict__})
            c.name = f"{base.name}_{g['tag']}"
            c.use_intervention_dummy = True
            c.use_variance_shock = bool(g["use_variance_shock"])
            c.use_post_level_shift = bool(g["use_post_level_shift"])
            c.post_shift_year = int(getattr(args, "post_shift_year", 2022))
            cfgs.append(c)


    if int(args.skip_backtest) == 0:
        bt_out = os.path.join(args.outdir, "backtest_rolling")
        run_rolling_backtest(
            rng=rng,
            df_annual=df_annual,
            cfgs=cfgs,
            outdir=bt_out,
            window=int(args.window),
            hmax=int(args.hmax),
            n_draws_per_case=int(args.n_draws_per_case),
            taus=[0.1, 0.5, 0.9],
            band=0.80,
            last_origin_only=bool(int(args.last_origin_only)),
        )

    # full-sample forecast for next 5 years
    last_year = int(df_annual.loc[df_annual['births_total'].notna(), 'year'].max())
    forecast_years = [last_year + i for i in range(1, 6)]
    fc_out = os.path.join(args.outdir, "forecast_5y")
    fit_and_forecast_full_sample(
        rng=rng,
        df_annual=df_annual,
        cfgs=cfgs,
        outdir=fc_out,
        forecast_years=forecast_years,
        n_forecast_draws=int(args.n_forecast_draws),
    )

    print("Done. See:", args.outdir)


# -----------------------------
# VSCode cell (optional)
# -----------------------------
# Standard CLI entrypoint (PowerShell / CMD / bash)
if __name__ == "__main__" and "ipykernel" not in sys.modules:
    main()

#%%
# VSCode/Jupyter entrypoint (run this cell)
if __name__ == "__main__" and "ipykernel" in sys.modules:
    # VSCode/Jupyter: adjust paths if needed, then run the cell.
    ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    sys.argv = [
        sys.argv[0],
        "--annual", os.path.join(ROOT, "data", "fertility_annual_v3.csv"),
        "--panel", os.path.join(ROOT, "data", "fertility_panel_v3.csv"),
        "--outdir", os.path.join(ROOT, "outputs", "v4_run"),
        "--seed", "123",
        "--phi", "0.90",
        "--shock_years", "2020,2021,2022",
        "--shock_var_mult", "4.0",
        "--anchor_year", "2019",
        "--window", "12",
        "--hmax", "5",
        "--n_iter", "400",
        "--burn", "200",
        "--thin", "5",
        "--lasso_lambda", "0.15",
        "--n_draws_per_case", "300",
        "--n_forecast_draws", "1500",
    ]
    main()