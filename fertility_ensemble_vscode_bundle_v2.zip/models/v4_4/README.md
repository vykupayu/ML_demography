# Fertility forecasting – v4.4 (core vs UA/migration; 2×2 intervention grid)

## Co to dělá
- Odhadne 4 varianty modelu v jednom běhu (rolling backtest + 5y forecast):
  1) `core_varshock`   = CORE covariáty + *variance shock* (2020–2022)
  2) `core_postshift`  = CORE covariáty + *post-2022 level shift* (od `post_shift_year`)
  3) `ua_varshock`     = CORE + UA proxy + *variance shock*
  4) `ua_postshift`    = CORE + UA proxy + *post-2022 level shift*

- Stavový model: damped local linear trend (LLT) + LASSO (Laplace prior) na regresorech.
- Výstupy:
  - `outputs/v4_run/backtest_rolling/*` (cases + long draws + PIT/coverage/pinball by h)
  - `outputs/v4_run/forecast_5y/*` (forecast long draws + quantiles + fan chart)

## Rychlé spuštění (PowerShell / VSCode terminal)
Doporučuji spustit jako **jednu řádku**:

```powershell
python .\scripts\fertility_models_v4_4_core_vs_ua_grid.py --annual .\data\fertility_annual_v3.csv --outdir .\outputs\v4_run --seed 1 --window 12 --hmax 5 --n_iter 1200 --burn 400 --thin 4 --lasso_lambda 0.15 --n_draws_per_case 300 --n_forecast_draws 1500 --post_shift_year 2022
```

Víceřádkově v PowerShellu používej **backtick** (ne `^`):
```powershell
python .\scripts\fertility_models_v4_4_core_vs_ua_grid.py `
  --annual .\data\fertility_annual_v3.csv `
  --outdir .\outputs\v4_run `
  --seed 1 --window 12 --hmax 5 `
  --n_iter 1200 --burn 400 --thin 4 `
  --lasso_lambda 0.15 `
  --n_draws_per_case 300 `
  --n_forecast_draws 1500 `
  --post_shift_year 2022
```

## Spuštění přes #%% ve VSCode
Otevři skript a nahoře dej buňku:

```python
# %%
import os, sys
from scripts.fertility_models_v4_4_core_vs_ua_grid import main

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
argv = [
    "--annual", os.path.join(ROOT, "data", "fertility_annual_v3.csv"),
    "--outdir", os.path.join(ROOT, "outputs", "v4_run"),
    "--seed", "1",
    "--window", "12",
    "--hmax", "5",
    "--n_iter", "1200",
    "--burn", "400",
    "--thin", "4",
    "--lasso_lambda", "0.15",
    "--n_draws_per_case", "300",
    "--n_forecast_draws", "1500",
    "--post_shift_year", "2022",
]
main(argv)
```

## Co mi pošli zpátky (pro vyhodnocení)
Zabal a pošli složku `outputs/v4_run/` nebo aspoň:
- `outputs/v4_run/backtest_rolling/backtest_cases.csv`
- `outputs/v4_run/backtest_rolling/backtest_draws_long.csv.gz`
- `outputs/v4_run/backtest_rolling/backtest_metrics_by_h.csv`
- `outputs/v4_run/backtest_rolling/pinball_by_h.csv`
- `outputs/v4_run/backtest_rolling/pit_by_h.csv`
- `outputs/v4_run/forecast_5y/forecast_quantiles.csv`
- `outputs/v4_run/forecast_5y/forecast_draws_long.csv.gz`
- `outputs/v4_run/forecast_5y/fan_chart_forecast.png`
