# Structural fertility age-model (CZ): exposures + ASFR + tempo

This package contains a single runnable script:

- `scripts/structural_fertility_age_model.py`

## What it does (conceptually)

It uses the demographic identity:

**B_t = Σ_a N(a,t) · ASFR(a,t) / 1000**

and builds a parsimonious *structural* forecast by splitting the problem into:

1. **Exposure forecast**: N(a,t) is taken from a projection file (or forward file if you have it).
2. **Quantum forecast**: Q_t ≈ Σ_a ASFR(a,t)/1000 (≈ TFR proxy) is forecast by a damped local-linear-trend Bayesian model,
   with an option for:
   - 2020–2022 **variance shock**, and
   - post-2022 **level shift** (negative by prior + data).
3. **Tempo/timing forecast**: mean age (MAC) is forecast similarly; it shifts the fertility age-profile.
4. Combine into births:
   - ASFR(a,t) = 1000 * Q_t * W_a(t)
   - W_a(t) = baseline age profile shifted by predicted mean-age change
   - B_t = Σ_a N(a,t)·ASFR(a,t)/1000

The outputs include a 10–90% fan chart and a “planning quantile” line.

## Run (PowerShell / VSCode)

From the package root:

```powershell
python .\scripts\structural_fertility_age_model.py `
  --panel .\data\cz_fertility_panel_age_year_2001_2023.csv `
  --exp_forward .\data\cz_exposure_forward_2024_2028.csv `
  --exp_projection .\data\cz_exposure_projection_age_year_2025_2081.csv `
  --outdir .\outputs\structural_v1 `
  --seed 123 `
  --forecast_start 2025 `
  --forecast_horizon 5
```

## Expected outputs

- `fan_chart_births_2025_2029.png`
- `forecast_quantiles_2025_2029.csv`
- `quantum_proxy_history.png`
- `timing_proxy_history.png`
- `baseline_age_profile_Wa.png`
