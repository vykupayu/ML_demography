#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Structural fertility model (age × year) for CZ births.

Key identity:
    B_t = sum_a N(a,t) * ASFR(a,t) / 1000
We model ASFR as:
    ASFR(a,t) = 1000 * Q_t * W_a(t)
where:
    Q_t ≈ sum_a ASFR(a,t) / 1000  (quantum, ~TFR proxy)
    W_a(t) = age distribution of fertility rates (sum_a W_a(t)=1),
             shifted over time via a timing/tempo process (mean age).

Forecast pipeline:
 1) Forecast exposure N(a,t) from projection input.
 2) Forecast quantum Q_t (log scale) with damped local-linear-trend (LLT).
 3) Forecast timing (mean age) with damped LLT.
 4) Build W_a(t) by shifting a baseline age profile by the forecasted mean-age change.
 5) Combine to births and produce fan chart.

The model is intentionally parsimonious and "structural" (builds births from
exposures + age-specific fertility schedule), suitable for 5-year planning.
"""
from __future__ import annotations

import argparse
import os
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import math


# -----------------------------
# Utilities
# -----------------------------
def _ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def _savefig(path: str) -> None:
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()

def invgamma_sample(rng: np.random.Generator, a: float, b: float) -> float:
    # If X ~ InvGamma(a,b), then 1/X ~ Gamma(a, rate=b).
    # numpy.gamma uses shape and scale (scale = 1/rate).
    return 1.0 / rng.gamma(shape=a, scale=1.0/max(b, 1e-18))

def weighted_mean_age(ages: np.ndarray, asfr: np.ndarray) -> float:
    w = np.maximum(asfr, 0.0)
    s = float(np.sum(w))
    if s <= 0:
        return float(np.mean(ages))
    return float(np.sum(ages * w) / s)

def normalize(x: np.ndarray) -> np.ndarray:
    x = np.maximum(x, 0.0)
    s = float(np.sum(x))
    if s <= 0:
        return np.ones_like(x) / len(x)
    return x / s

def shift_profile_linear(ages: np.ndarray, w_base: np.ndarray, shift: float) -> np.ndarray:
    """
    Shift a discrete age profile by 'shift' years using linear interpolation.
    Positive shift moves fertility to older ages.
    """
    # target age grid is the same; we evaluate base profile at (age - shift)
    x = ages.astype(float)
    x_src = x - float(shift)
    w = np.interp(x_src, x, w_base, left=0.0, right=0.0)
    return normalize(w)


# -----------------------------
# Damped LLT + FFBS
# -----------------------------
def ffbs_llt_damped(
    rng: np.random.Generator,
    y: np.ndarray,
    phi: float,
    sig_y2: float,
    sig_l2: float,
    sig_b2: float,
    shock_mask: Optional[np.ndarray] = None,
    shock_var_mult: float = 1.0,
) -> np.ndarray:
    """
    y_t = level_t + e_t,  e_t ~ N(0, sig_y2 * mult_t)
    level_t = level_{t-1} + phi*slope_{t-1} + u_t, u_t ~ N(0, sig_l2)
    slope_t = slope_{t-1} + v_t, v_t ~ N(0, sig_b2)

    Returns sampled states array [T,2] columns: level, slope
    """
    y = np.asarray(y, float)
    T = len(y)
    if shock_mask is None:
        shock_mask = np.zeros(T, dtype=bool)
    mult = np.where(shock_mask, shock_var_mult, 1.0).astype(float)

    F = np.array([[1.0, phi],
                  [0.0, 1.0]], dtype=float)
    Q = np.array([[sig_l2, 0.0],
                  [0.0, sig_b2]], dtype=float)
    H = np.array([[1.0, 0.0]], dtype=float)

    # diffuse-ish priors
    m = np.array([y[0], 0.0], dtype=float)
    C = np.eye(2) * 1e2

    m_f = np.zeros((T, 2))
    C_f = np.zeros((T, 2, 2))
    a_f = np.zeros((T, 2))
    R_f = np.zeros((T, 2, 2))

    for t in range(T):
        # predict
        if t == 0:
            a = m.copy()
            R = C.copy()
        else:
            a = F @ m
            R = F @ C @ F.T + Q

        # update
        yt = y[t]
        Rt_y = sig_y2 * mult[t]
        S = float(H @ R @ H.T + Rt_y)  # scalar
        K = (R @ H.T) / max(S, 1e-18)  # (2,1)
        e = yt - float(H @ a)
        m = a + (K[:, 0] * e)
        C = R - (K @ H @ R)

        a_f[t] = a
        R_f[t] = R
        m_f[t] = m
        C_f[t] = C

    # backward sampling
    states = np.zeros((T, 2))
    states[T-1] = rng.multivariate_normal(mean=m_f[T-1], cov=C_f[T-1] + 1e-12*np.eye(2))
    for t in range(T-2, -1, -1):
        Rn = R_f[t+1]
        J = C_f[t] @ F.T @ np.linalg.inv(Rn + 1e-12*np.eye(2))
        mean = m_f[t] + J @ (states[t+1] - a_f[t+1])
        cov = C_f[t] - J @ Rn @ J.T
        cov = (cov + cov.T)/2.0
        states[t] = rng.multivariate_normal(mean=mean, cov=cov + 1e-12*np.eye(2))
    return states


@dataclass
class LLTConfig:
    phi: float = 0.95
    shock_years: Tuple[int, int] = (2020, 2022)  # inclusive
    shock_var_mult: float = 4.0
    use_variance_shock: bool = True

    use_post_level_shift: bool = False
    post_shift_year: int = 2023  # D_t=1 for year>=post_shift_year

    # priors
    a_y: float = 2.5
    b_y: float = 0.5
    a_l: float = 2.5
    b_l: float = 0.2
    a_b: float = 2.5
    b_b: float = 0.05

    # mcmc
    n_iter: int = 2500
    burn: int = 1000
    thin: int = 5


def fit_llt_gibbs(
    rng: np.random.Generator,
    years: np.ndarray,
    y: np.ndarray,
    cfg: LLTConfig,
    prior_delta_sd: float = 0.15,
) -> Dict[str, np.ndarray]:
    """
    Fit damped LLT with optional post level shift:
        y_t = level_t + delta*D_t + e_t

    Returns posterior draws for:
      states_draws: [n_keep, T, 2]
      sig_y2, sig_l2, sig_b2: [n_keep]
      delta: [n_keep] (0 if not used)
    """
    years = np.asarray(years, int)
    y = np.asarray(y, float)
    T = len(y)

    # shock mask (obs noise inflation)
    if cfg.use_variance_shock:
        shock_mask = (years >= cfg.shock_years[0]) & (years <= cfg.shock_years[1])
    else:
        shock_mask = np.zeros(T, dtype=bool)

    if cfg.use_post_level_shift:
        D = (years >= cfg.post_shift_year).astype(float)
    else:
        D = np.zeros(T, dtype=float)

    # init
    sig_y2 = float(np.var(y) * 0.2 + 1e-6)
    sig_l2 = float(np.var(y) * 0.05 + 1e-6)
    sig_b2 = float(np.var(y) * 0.01 + 1e-6)
    delta = 0.0

    # storage
    keep_idx = []
    states_kept = []
    sig_y2_kept = []
    sig_l2_kept = []
    sig_b2_kept = []
    delta_kept = []

    for it in range(cfg.n_iter):
        # 1) sample states conditional on delta
        y_adj = y - delta * D
        states = ffbs_llt_damped(
            rng=rng,
            y=y_adj,
            phi=cfg.phi,
            sig_y2=sig_y2,
            sig_l2=sig_l2,
            sig_b2=sig_b2,
            shock_mask=shock_mask,
            shock_var_mult=cfg.shock_var_mult,
        )
        level = states[:, 0]
        slope = states[:, 1]

        # 2) sample delta (if used): y - level = delta*D + e
        if cfg.use_post_level_shift:
            resid = y - level
            # effective noise variance per t
            mult = np.where(shock_mask, cfg.shock_var_mult, 1.0)
            w = 1.0 / (sig_y2 * mult + 1e-12)
            # posterior for delta in weighted regression with N(0, prior_delta_sd^2)
            XtW = float(np.sum(D * D * w))
            XyW = float(np.sum(D * resid * w))
            prec = XtW + 1.0/(prior_delta_sd**2)
            var = 1.0 / max(prec, 1e-12)
            mean = var * XyW
            delta = float(rng.normal(loc=mean, scale=math.sqrt(max(var, 1e-12))))
        else:
            delta = 0.0

        # 3) sample variances
        # obs variance: y - (level + delta*D)
        resid = y - (level + delta * D)
        mult = np.where(shock_mask, cfg.shock_var_mult, 1.0)
        resid_scaled = resid / np.sqrt(mult)
        a_post = cfg.a_y + 0.5 * T
        b_post = cfg.b_y + 0.5 * float(np.dot(resid_scaled, resid_scaled))
        sig_y2 = invgamma_sample(rng, a_post, b_post)

        # level innovation variance
        innov_l = level[1:] - (level[:-1] + cfg.phi * slope[:-1])
        a_post = cfg.a_l + 0.5 * (T-1)
        b_post = cfg.b_l + 0.5 * float(np.dot(innov_l, innov_l))
        sig_l2 = invgamma_sample(rng, a_post, b_post)

        # slope innovation variance
        innov_b = slope[1:] - slope[:-1]
        a_post = cfg.a_b + 0.5 * (T-1)
        b_post = cfg.b_b + 0.5 * float(np.dot(innov_b, innov_b))
        sig_b2 = invgamma_sample(rng, a_post, b_post)

        # keep
        if it >= cfg.burn and ((it - cfg.burn) % cfg.thin == 0):
            states_kept.append(states.copy())
            sig_y2_kept.append(sig_y2)
            sig_l2_kept.append(sig_l2)
            sig_b2_kept.append(sig_b2)
            delta_kept.append(delta)

    return {
        "states": np.stack(states_kept, axis=0),
        "sig_y2": np.array(sig_y2_kept),
        "sig_l2": np.array(sig_l2_kept),
        "sig_b2": np.array(sig_b2_kept),
        "delta": np.array(delta_kept),
        "shock_mask": shock_mask.astype(int),
        "D": D,
    }


def simulate_future_llt(
    rng: np.random.Generator,
    years_obs: np.ndarray,
    years_fut: np.ndarray,
    post: Dict[str, np.ndarray],
    cfg: LLTConfig,
    on_log_scale: bool,
) -> np.ndarray:
    """
    Simulate future observation draws y_{fut} using posterior draws.
    Returns array [n_draws, H] for H=len(years_fut).
    """
    years_obs = np.asarray(years_obs, int)
    years_fut = np.asarray(years_fut, int)
    H = len(years_fut)

    states = post["states"]
    sig_y2 = post["sig_y2"]
    sig_l2 = post["sig_l2"]
    sig_b2 = post["sig_b2"]
    delta = post["delta"]

    n_draws = states.shape[0]
    out = np.zeros((n_draws, H), dtype=float)

    # future masks
    if cfg.use_variance_shock:
        shock_f = (years_fut >= cfg.shock_years[0]) & (years_fut <= cfg.shock_years[1])
    else:
        shock_f = np.zeros(H, dtype=bool)
    if cfg.use_post_level_shift:
        D_f = (years_fut >= cfg.post_shift_year).astype(float)
    else:
        D_f = np.zeros(H, dtype=float)

    for i in range(n_draws):
        level_T, slope_T = states[i, -1, 0], states[i, -1, 1]
        l, b = float(level_T), float(slope_T)
        sy2, sl2, sb2 = float(sig_y2[i]), float(sig_l2[i]), float(sig_b2[i])
        dlt = float(delta[i])

        for h in range(H):
            # state evolution
            l = l + cfg.phi * b + rng.normal(0.0, math.sqrt(max(sl2, 1e-12)))
            b = b + rng.normal(0.0, math.sqrt(max(sb2, 1e-12)))
            # observation
            mult = cfg.shock_var_mult if shock_f[h] else 1.0
            y_h = l + dlt * D_f[h] + rng.normal(0.0, math.sqrt(max(sy2 * mult, 1e-12)))
            out[i, h] = y_h

    if on_log_scale:
        out = np.exp(out)
    return out


# -----------------------------
# Structural fertility model
# -----------------------------
@dataclass
class StructuralConfig:
    # baseline for age-profile W_a
    w_base_years: Tuple[int, int] = (2015, 2019)
    use_mac: bool = True  # timing target: MAC if available else mean-age-from-ASFR

    # quantum model config
    q_cfg: LLTConfig = field(default_factory=lambda: LLTConfig(
        phi=0.92,
        shock_years=(2020, 2022),
        shock_var_mult=4.0,
        use_variance_shock=True,
        use_post_level_shift=True,
        post_shift_year=2023,
        # slightly informative priors to avoid explosive rebounds
        a_y=2.5, b_y=0.2,
        a_l=2.5, b_l=0.05,
        a_b=2.5, b_b=0.02,
        n_iter=2600, burn=1000, thin=5,
    ))

    # timing model config
    m_cfg: LLTConfig = field(default_factory=lambda: LLTConfig(
        phi=0.95,
        shock_years=(2020, 2022),
        shock_var_mult=2.0,
        use_variance_shock=True,
        use_post_level_shift=False,
        n_iter=2200, burn=800, thin=5,
        a_y=2.5, b_y=0.05,
        a_l=2.5, b_l=0.01,
        a_b=2.5, b_b=0.005,
    ))

    # optional: impose "expert" near-term nowcast for 2025 via multiplicative change to births
    # (approx from CSÚ half-year note). If None, no adjustment.
    nowcast_2025_yoy_change: Optional[float] = -0.12  # e.g., -0.12 = -12%

    # planning quantile for capacity (higher quantile -> more conservative capacity)
    planning_tau: float = 5/6  # ~0.833

def load_panel(panel_csv: str) -> pd.DataFrame:
    df = pd.read_csv(panel_csv)
    # expected columns (flexible naming)
    # required: year, age, N, ASFR_per_1000
    required = {"year", "age"}
    if not required.issubset(df.columns):
        raise ValueError(f"Missing columns in panel: {required - set(df.columns)}")
    # normalize common column names
    colmap = {}
    if "N" not in df.columns:
        for c in df.columns:
            if c.lower() in ("n", "n_women", "exposure", "women"):
                colmap[c] = "N"
    if "ASFR_per_1000" not in df.columns:
        for c in df.columns:
            if c.lower() in ("asfr", "asfr_per_1000", "fertility_rate"):
                colmap[c] = "ASFR_per_1000"
    if colmap:
        df = df.rename(columns=colmap)
    if "N" not in df.columns or "ASFR_per_1000" not in df.columns:
        raise ValueError("Panel must contain 'N' and 'ASFR_per_1000' columns.")
    return df


def aggregate_yearly(df_panel: pd.DataFrame) -> pd.DataFrame:
    # Compute births from identity and also use provided B if available
    df = df_panel.copy()
    df["B_from_N_ASFR"] = df["N"] * df["ASFR_per_1000"] / 1000.0
    agg = df.groupby("year").agg(
        births_from_identity=("B_from_N_ASFR", "sum"),
        births_B=("B", "sum") if "B" in df.columns else ("B_from_N_ASFR", "sum"),
        q_tfr=("ASFR_per_1000", lambda s: float(np.sum(s) / 1000.0)),
        mean_age_from_asfr=("ASFR_per_1000", lambda s: np.nan),  # placeholder
        MAC=("MAC", "mean") if "MAC" in df.columns else ("ASFR_per_1000", lambda s: np.nan),
        MA_first=("MA_first", "mean") if "MA_first" in df.columns else ("ASFR_per_1000", lambda s: np.nan),
    ).reset_index()

    # mean age implied by ASFR
    ages = np.sort(df["age"].unique())
    for i, y in enumerate(agg["year"].to_numpy()):
        sub = df.loc[df["year"] == y].sort_values("age")
        agg.loc[i, "mean_age_from_asfr"] = weighted_mean_age(sub["age"].to_numpy(), sub["ASFR_per_1000"].to_numpy())

    # pick births_total: prefer B if present, else identity
    if "B" in df.columns:
        agg["births_total"] = agg["births_B"]
    else:
        agg["births_total"] = agg["births_from_identity"]
    return agg


def build_w_base(df_panel: pd.DataFrame, years_range: Tuple[int, int]) -> Tuple[np.ndarray, np.ndarray]:
    y0, y1 = years_range
    sub = df_panel[(df_panel["year"] >= y0) & (df_panel["year"] <= y1)].copy()
    if sub.empty:
        raise ValueError("No rows for w_base_years range.")
    ages = np.sort(sub["age"].unique())
    # average ASFR across years, then normalize into W_a
    asfr_mean = sub.groupby("age")["ASFR_per_1000"].mean().reindex(ages).to_numpy()
    w_base = normalize(asfr_mean)
    return ages, w_base


def load_exposure_future(exp_forward_csv: str, exp_projection_csv: str, years_fut: List[int]) -> pd.DataFrame:
    fwd = pd.read_csv(exp_forward_csv)
    proj = pd.read_csv(exp_projection_csv)

    # minimal validation
    for name, d in (("forward", fwd), ("projection", proj)):
        if "age" not in d.columns or "year" not in d.columns:
            raise ValueError(f"Exposure {name} file must contain 'year' and 'age' columns.")

    # Determine exposure column names
    # forward: prefer "N", else any column starting with "n"
    if "N" not in fwd.columns:
        cand = [c for c in fwd.columns if c.lower().startswith("n")]
        if not cand:
            raise ValueError("Forward exposure file must contain N (or a column starting with 'n').")
        fwd = fwd.rename(columns={cand[0]: "N"})

    # projection: prefer "N_proj", else "N", else any n*
    if "N_proj" not in proj.columns:
        if "N" in proj.columns:
            proj = proj.rename(columns={"N": "N_proj"})
        else:
            cand = [c for c in proj.columns if c.lower().startswith("n")]
            if not cand:
                raise ValueError("Projection exposure file must contain N_proj (or N / a column starting with 'n').")
            proj = proj.rename(columns={cand[0]: "N_proj"})

    # merge with preference: use forward if available, else projection
    out_rows = []
    for y in years_fut:
        if (fwd["year"] == y).any():
            tmp = fwd[fwd["year"] == y][["year", "age", "N"]].copy()
            tmp["source"] = "forward"
        else:
            tmp = proj[proj["year"] == y][["year", "age", "N_proj"]].copy()
            tmp = tmp.rename(columns={"N_proj": "N"})
            tmp["source"] = "projection"
        out_rows.append(tmp)
    out = pd.concat(out_rows, ignore_index=True)
    return out


def quantiles(draws: np.ndarray, qs: List[float]) -> np.ndarray:
    return np.quantile(draws, qs, axis=0)


def run(panel_csv: str,
        exp_forward_csv: str,
        exp_projection_csv: str,
        outdir: str,
        seed: int = 123,
        forecast_start: int = 2025,
        forecast_horizon: int = 5) -> None:

    _ensure_dir(outdir)
    rng = np.random.default_rng(seed)

    # Load and aggregate
    df_panel = load_panel(panel_csv)
    yearly = aggregate_yearly(df_panel)

    # Observed years for model fitting (from panel)
    years_obs = yearly["year"].to_numpy(dtype=int)
    # quantum proxy
    q_obs = yearly["q_tfr"].to_numpy(dtype=float)
    yq_obs = np.log(np.maximum(q_obs, 1e-12))

    # timing proxy
    if "MAC" in yearly.columns and yearly["MAC"].notna().any():
        m_obs = yearly["MAC"].to_numpy(dtype=float)
        m_label = "MAC (mean age at childbearing)"
    else:
        m_obs = yearly["mean_age_from_asfr"].to_numpy(dtype=float)
        m_label = "mean age implied by ASFR"

    cfg = StructuralConfig()

    # Optional fast settings for demo / CI environments:
    # set environment variable FAST_DEMO=1 to reduce MCMC iterations.
    if os.environ.get("FAST_DEMO", "0") == "1":
        cfg.q_cfg.n_iter, cfg.q_cfg.burn, cfg.q_cfg.thin = 900, 300, 6
        cfg.m_cfg.n_iter, cfg.m_cfg.burn, cfg.m_cfg.thin = 800, 250, 6

    # baseline age profile
    ages, w_base = build_w_base(df_panel, cfg.w_base_years)

    # Fit quantum (log scale)
    post_q = fit_llt_gibbs(
        rng=rng,
        years=years_obs,
        y=yq_obs,
        cfg=cfg.q_cfg,
        prior_delta_sd=0.25,  # allow post-2022 negative shift
    )

    # Fit timing (original scale)
    post_m = fit_llt_gibbs(
        rng=rng,
        years=years_obs,
        y=m_obs,
        cfg=cfg.m_cfg,
        prior_delta_sd=0.5,
    )

    # Forecast years
    years_fut = np.array([forecast_start + i for i in range(forecast_horizon)], dtype=int)

    # Exposure future
    exp_fut = load_exposure_future(exp_forward_csv, exp_projection_csv, years_fut.tolist())
    exp_fut = exp_fut[exp_fut["age"].isin(ages)].copy()

    # Posterior predictive draws
    Q_draws = simulate_future_llt(
        rng=rng,
        years_obs=years_obs,
        years_fut=years_fut,
        post=post_q,
        cfg=cfg.q_cfg,
        on_log_scale=True,
    )  # [n_draws, H]

    M_draws = simulate_future_llt(
        rng=rng,
        years_obs=years_obs,
        years_fut=years_fut,
        post=post_m,
        cfg=cfg.m_cfg,
        on_log_scale=False,
    )  # [n_draws, H]

    # Align number of draws across quantum and timing models
    n_draws = int(min(Q_draws.shape[0], M_draws.shape[0]))
    Q_draws = Q_draws[:n_draws, :]
    M_draws = M_draws[:n_draws, :]

    # Optional nowcast: apply multiplicative adjustment to births in 2025 (first forecast year)
    # implemented as adjustment to Q for that year (approx)
    if cfg.nowcast_2025_yoy_change is not None:
        # determine yoy change relative to last observed year births_total
        yoy = float(cfg.nowcast_2025_yoy_change)
        # approximate: apply to Q at first horizon and linearly fade out by year 3
        fade = np.array([1.0, 0.66, 0.33, 0.0, 0.0], dtype=float)[:len(years_fut)]
        adj = np.exp(np.log(1.0 + yoy) * fade)  # multiplicative
        Q_draws = Q_draws * adj[None, :]

    # Build births draws
    # Baseline mean age from base window
    base_years = np.arange(cfg.w_base_years[0], cfg.w_base_years[1] + 1)
    base_m = float(np.nanmean(yearly.loc[yearly["year"].isin(base_years), "MAC"].to_numpy()))
    if not np.isfinite(base_m):
        base_m = float(np.nanmean(yearly.loc[yearly["year"].isin(base_years), "mean_age_from_asfr"].to_numpy()))

    # Precompute exposure matrices aligned (H, A)
    exp_mat = np.zeros((len(years_fut), len(ages)), dtype=float)
    for i, y in enumerate(years_fut):
        tmp = exp_fut.loc[exp_fut["year"] == y].set_index("age").reindex(ages)["N"].to_numpy()
        exp_mat[i, :] = tmp.astype(float)

    # n_draws already aligned above
    B_draws = np.zeros((n_draws, len(years_fut)), dtype=float)

    for i in range(n_draws):
        for h, y in enumerate(years_fut):
            shift = float(M_draws[i, h] - base_m)
            w = shift_profile_linear(ages, w_base, shift)
            # births = sum N * (1000*Q*w)/1000 = Q * sum N*w
            B_draws[i, h] = float(Q_draws[i, h] * np.dot(exp_mat[h, :], w))

    # Quantiles for fan chart
    qs = [0.10, 0.50, 0.90, cfg.planning_tau]
    qvals = quantiles(B_draws, qs)  # [len(qs), H]

    out_q = pd.DataFrame({
        "year": years_fut,
        "q10": qvals[0],
        "q50": qvals[1],
        "q90": qvals[2],
        "q_plan": qvals[3],
    })
    out_q.to_csv(os.path.join(outdir, "forecast_quantiles_2025_2029.csv"), index=False)
    # --- ADD: save forecast draws (long) for ensemble ---
    draws_long = pd.DataFrame({
        "draw_id": np.repeat(np.arange(B_draws.shape[0]), B_draws.shape[1]),
        "year": np.tile(years_fut, B_draws.shape[0]),
        "births": B_draws.reshape(-1),
    })
    draws_long.to_csv(
        os.path.join(outdir, "forecast_draws_long.csv.gz"),
        index=False,
        compression="gzip",
    )
    # --- END ADD ---

    # Plot 1: quantum and timing history
    plt.figure(figsize=(10, 4))
    plt.plot(years_obs, q_obs, label="Q_t (≈TFR proxy)")
    plt.title("Quantum proxy Q_t (sum ASFR / 1000)")
    plt.xlabel("Year")
    plt.ylabel("Q_t")
    _savefig(os.path.join(outdir, "quantum_proxy_history.png"))

    plt.figure(figsize=(10, 4))
    plt.plot(years_obs, m_obs, label=m_label)
    plt.title("Timing proxy (tempo): mean age time series")
    plt.xlabel("Year")
    plt.ylabel("Age")
    _savefig(os.path.join(outdir, "timing_proxy_history.png"))

    # Plot 2: baseline W_a
    plt.figure(figsize=(10, 4))
    plt.plot(ages, w_base)
    plt.title(f"Baseline age profile W_a (avg {cfg.w_base_years[0]}–{cfg.w_base_years[1]})")
    plt.xlabel("Age")
    plt.ylabel("W_a (sums to 1)")
    _savefig(os.path.join(outdir, "baseline_age_profile_Wa.png"))

    # Plot 3: births fan chart with history
    hist_years = yearly["year"].to_numpy(dtype=int)
    hist_births = yearly["births_total"].to_numpy(dtype=float)

    plt.figure(figsize=(12, 6))
    plt.plot(hist_years, hist_births, label="Skutečnost (ČSÚ)")
    q10 = out_q["q10"].to_numpy(dtype=float)
    q50 = out_q["q50"].to_numpy(dtype=float)
    q90 = out_q["q90"].to_numpy(dtype=float)
    qpl = out_q["q_plan"].to_numpy(dtype=float)
    plt.fill_between(years_fut.astype(float), q10, q90, alpha=0.25, label="Predikční pásmo 10–90 %")
    plt.plot(years_fut, q50, linestyle="--", label="Medián (q50)")
    plt.plot(years_fut, qpl, linestyle=":", label=f"Plánovací kvantil (τ={cfg.planning_tau:.3f})")
    plt.title("Počet živě narozených v ČR: strukturální model (expozice + ASFR) – 5letá předpověď")
    plt.xlabel("Rok")
    plt.ylabel("Počet živě narozených")
    plt.legend()
    _savefig(os.path.join(outdir, "fan_chart_births_2025_2029.png"))

    print("[saved]", os.path.join(outdir, "forecast_quantiles_2025_2029.csv"))
    print("[saved]", os.path.join(outdir, "fan_chart_births_2025_2029.png"))
    print("[saved]", os.path.join(outdir, "quantum_proxy_history.png"))
    print("[saved]", os.path.join(outdir, "timing_proxy_history.png"))
    print("[saved]", os.path.join(outdir, "baseline_age_profile_Wa.png"))


def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    p.add_argument("--panel", type=str, required=True, help="Panel CSV (age×year) with N and ASFR_per_1000.")
    p.add_argument("--exp_forward", type=str, required=True, help="Exposure forward CSV (e.g., 2024–2028).")
    p.add_argument("--exp_projection", type=str, required=True, help="Exposure projection CSV (e.g., 2025–2081).")
    p.add_argument("--outdir", type=str, required=True, help="Output directory.")
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--forecast_start", type=int, default=2025)
    p.add_argument("--forecast_horizon", type=int, default=5)
    return p


def main(argv=None) -> None:
    args = build_argparser().parse_args(argv)
    run(
        panel_csv=args.panel,
        exp_forward_csv=args.exp_forward,
        exp_projection_csv=args.exp_projection,
        outdir=args.outdir,
        seed=args.seed,
        forecast_start=args.forecast_start,
        forecast_horizon=args.forecast_horizon,
    )

if __name__ == "__main__":
    main()