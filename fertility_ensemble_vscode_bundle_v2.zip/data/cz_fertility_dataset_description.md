# Společný dataset pro modelování živě narozených v ČR (ČSÚ Open Data)

## Co je v souborech
- **Hlavní panel (věk × rok):** `cz_fertility_panel_age_year_2001_2023.csv`  
  Granularita: **jednoletý věk matky/ženy a = 15…49** a **rok t = 2001…2023**, území **Česko (CZ)**.
- **Rozšířený panel (věk × rok):** `cz_fertility_panel_age_year_full.csv`  
  Obsahuje i roky mimo 2001–2023 (podle dostupnosti jednotlivých zdrojů).
- **Projekce expozic (věk × rok):** `cz_exposure_projection_age_year_2025_2081.csv`  
  Ženy 15–49, roky 2025–2081; součet přes kraje (národní úroveň).
- **Forward expozice pro 5letý horizont:** `cz_exposure_forward_2024_2028.csv`  
  Pozn.: projekce začíná **2025**, proto jsou dostupné roky **2025–2028** (rok 2024 v této projekci není).

## Zdroje (ČSÚ Open Data)
- **OBY02BHVD** – Počet obyvatel k 31. 12. podle věku a pohlaví (expozice).
- **OBY03D** – Míry plodnosti (ASFR) podle věku.
- **OBY03B** – Živě narození podle věku matky (filtrováno na Rodinný stav = Celkem, Pořadí narození = Celkem).
- **OBY03** – Souhrnné ukazatele narození (vytažené řady: průměrný věk matky při porodu, průměrný věk při 1. porodu).
- **OBY02PROJ2** – Projekce obyvatelstva po krajích (ženy; pro národní úroveň sečteno přes kraje).

## Datový slovník (hlavní panel)
Každý řádek odpovídá kombinaci **(a,t)**.

| proměnná | význam | jednotka / měřítko | poznámka pro model |
|---|---|---|---|
| `year` (= t) | kalendářní rok | rok | časový index |
| `age` (= a) | věk ženy / věk matky | roky (jednoletý) | věk 15–49 |
| `N` (= N(a,t)) | **expozice**: počet žen ve věku *a* v roce *t* (k 31.12.) | osoby | zachycuje velikost kohort (demografická struktura) |
| `ASFR_per_1000` (= ASFR(a,t)) | **věkově specifická plodnost** | živě narození na 1 000 žen | „tvar“ věkového profilu plodnosti |
| `B` (= B(a,t)) | **živě narození** matkám ve věku *a* v roce *t* | osoby | můžeš modelovat přímo jako count (např. Poisson/NegBin) |
| `B_hat_from_N_ASFR` | implikované porody z `N` a `ASFR_per_1000` | osoby | `N * ASFR/1000` (kontrola konzistence / alternativní konstrukt) |
| `MAC` | průměrný věk matky při narození dítěte | roky | proxy pro **tempo effect** (odkládání) |
| `MA_first` | průměrný věk matky při narození 1. dítěte | roky | citlivější na odkládání prvního porodu |

## Důležité definice pro prompt

### 1) Expozice: **N(a,t)**
- Interpretace: počet žen ve věku **a** v roce **t** (v panelu pro Česko).
- Prakticky: používá se jako „kolik žen je v daném věku“ → demografická struktura a velikost kohort.
- Poznámka: v tomto zdroji je to **stav k 31.12.** daného roku.

### 2) Porody a plodnost: **B(a,t)** a **ASFR(a,t)**
- `B(a,t)` = počet živě narozených matkám ve věku **a** v roce **t** (count).
- `ASFR(a,t)` = věkově specifická míra plodnosti (živě narození na **1 000** žen ve věku **a**).
- Vztah (užitečné pro kontrolu / konstrukci likelihoodu):
  \[
  \hat B(a,t) = N(a,t) \cdot \frac{ASFR(a,t)}{1000}.
  \]

## Vygenerované grafy
- `plot_exposure_20_39_heatmap.png` – expozice žen 20–39 (věk × rok)
- `plot_asfr_profiles_selected_years.png` – profily ASFR pro roky [2001, 2010, 2015, 2023]
- `plot_mean_age_time_series.png` – časová řada MAC a MA_first
